package tv.own.owntv.core.metadata
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
class ProgrammeInformationParserTest {
    @Test fun `cast portraits match names and preserve roles`() {
        val base = ExternalTitleMetadata(0, MetadataType.TV, "Example", castPhotos = mapOf("pedro pascal" to "https://artworks.thetvdb.com/banners/actor.jpg"))
        val info = ProgrammeInformationParser.parse(base, null, JSONObject("""{"cast":[{"characters":["Din Djarin"],"person":{"name":"Pedro Pascal"}}]}"""), emptyList())
        assertEquals("Din Djarin", info.cast.single().role)
        assertEquals(base.castPhotos.values.single(),info.cast.single().photoUrl)
    }
    @Test fun `character artwork is never used as actor photo`() {
        assertTrue(TvdbCastPhotos.parse(JSONArray("""[{"personName":"Actor","image":"/banners/character.jpg"}]""")).isEmpty())
        assertEquals("https://artworks.thetvdb.com/banners/actor.jpg",TvdbCastPhotos.parse(JSONArray("""[{"personName":"Actor","personImgURL":"/banners/actor.jpg"}]"""))["actor"])
    }
    @Test fun `seasons keep specials and reject missing numbers`() {
        assertEquals(listOf(0,2),ProgrammeInformationParser.seasons(JSONArray("""[{"number":2},{"title":"Unknown"},{"number":0},{"number":-1}]""")).map { it.number })
    }
    @Test fun `requested episode translation falls back to base overview`() {
        val episode=ProgrammeInformationParser.episodes(JSONArray("""[{"number":1,"title":"Base","overview":"Overview","translations":[{"language":"es","title":"Título","overview":null}]}]"""),"es").single()
        assertEquals("Título",episode.title);assertEquals("Overview",episode.overview)
    }
}
