package tv.own.owntv.core.metadata
import java.text.Normalizer
import java.util.Locale
import org.json.JSONArray
internal object TvdbCastPhotos {
    fun nameKey(name: String) = Normalizer.normalize(name, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        .lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
    fun parse(rows: JSONArray?): Map<String, String> {
        if (rows == null) return emptyMap()
        return (0 until rows.length()).mapNotNull { i ->
            val row = rows.optJSONObject(i) ?: return@mapNotNull null
            val name = row.optString("personName").takeIf { it.isNotBlank() && it != "null" } ?: return@mapNotNull null
            val raw = row.optString("personImgURL").trim()
            val url = when { raw.startsWith("https://artworks.thetvdb.com/banners/") -> raw
                raw.startsWith("/banners/") -> "https://artworks.thetvdb.com$raw"; else -> return@mapNotNull null }
            nameKey(name) to url
        }.groupBy({ it.first }, { it.second }).mapNotNull { (name, urls) -> urls.distinct().singleOrNull()?.let { name to it } }.toMap()
    }
}
