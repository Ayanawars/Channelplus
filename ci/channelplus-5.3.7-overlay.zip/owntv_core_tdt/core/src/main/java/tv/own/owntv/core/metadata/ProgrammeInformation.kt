package tv.own.owntv.core.metadata
import org.json.JSONArray
import org.json.JSONObject

data class ProgrammePerson(val name: String, val role: String?, val photoUrl: String? = null)
data class ProgrammeSeason(val number: Int, val title: String?, val episodes: Int?)
data class ProgrammeEpisode(val number: Int, val title: String?, val overview: String?, val firstAired: String?, val runtime: Int?)
data class ProgrammeInformation(val base: ExternalTitleMetadata?, val originalTitle: String? = null, val runtime: Int? = null,
    val country: String? = null, val language: String? = null, val status: String? = null, val network: String? = null,
    val firstAired: String? = null, val tagline: String? = null, val cast: List<ProgrammePerson> = emptyList(),
    val directors: List<String> = emptyList(), val writers: List<String> = emptyList(), val seasons: List<ProgrammeSeason> = emptyList(),
    val incomplete: Boolean = false, val loading: Boolean = false)
internal object ProgrammeInformationParser {
    private fun JSONObject.text(key: String) = optString(key).takeIf { it.isNotBlank() && it != "null" }
    private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }
    fun parse(base: ExternalTitleMetadata, summary: JSONObject?, people: JSONObject?, seasons: List<ProgrammeSeason>): ProgrammeInformation {
        fun crew(key: String) = people?.optJSONObject("crew")?.optJSONArray(key).objects().mapNotNull { it.optJSONObject("person")?.text("name") }.distinct()
        val cast = people?.optJSONArray("cast").objects().mapNotNull { row ->
            val name = row.optJSONObject("person")?.text("name") ?: return@mapNotNull null
            val roles = row.optJSONArray("characters")?.let { a -> (0 until a.length()).mapNotNull { a.optString(it).takeIf { v -> v.isNotBlank() && v != "null" } }.joinToString(" / ").takeIf { it.isNotBlank() } } ?: row.text("character")
            ProgrammePerson(name, roles, base.castPhotos[TvdbCastPhotos.nameKey(name)])
        }.distinctBy { it.name }.take(40)
        return ProgrammeInformation(base, summary?.text("title"), summary?.optInt("runtime")?.takeIf { it > 0 }, summary?.text("country"), summary?.text("language"),
            summary?.text("status"), summary?.text("network"), (summary?.text("first_aired") ?: summary?.text("released"))?.take(10), summary?.text("tagline"), cast, crew("directing"), crew("writing"), seasons)
    }
    fun seasons(rows: JSONArray) = rows.objects().mapNotNull { row ->
        if (!row.has("number") || row.isNull("number")) null else row.optInt("number").takeIf { it >= 0 }?.let { ProgrammeSeason(it, row.text("title"), row.optInt("episode_count").takeIf { n -> n > 0 }) }
    }.distinctBy { it.number }.sortedBy { it.number }
    fun episodes(rows: JSONArray, language: String) = rows.objects().mapNotNull { row ->
        val number = row.optInt("number").takeIf { it > 0 } ?: return@mapNotNull null
        val translated = row.optJSONArray("translations").objects().firstOrNull { it.optString("language") == language }
        ProgrammeEpisode(number, translated?.text("title") ?: row.text("title"), translated?.text("overview") ?: row.text("overview"), row.text("first_aired")?.take(10), row.optInt("runtime").takeIf { it > 0 })
    }.sortedBy { it.number }
}
