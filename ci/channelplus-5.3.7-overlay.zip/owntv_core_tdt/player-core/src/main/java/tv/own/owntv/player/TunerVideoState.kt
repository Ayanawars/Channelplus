package tv.own.owntv.player

/** Only the existing tuner publishes readiness; HbbTV must not tune a second session. */
data class TunerVideoState(
    val inputId: String? = null,
    val channelId: Long = -1,
    val videoReady: Boolean = false,
    val generation: Long = 0,
)
