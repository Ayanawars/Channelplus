# Channel+ 5.3.4 — integración de televisión interactiva

Base: instantánea completa de fuentes de la versión publicada 5.3.3, no la rama main anterior. Se mantienen el paquete tv.own.owntv.tdt2, las listas, los perfiles, los ajustes y la firma original. Código de versión 100013.

## Acceso

Mientras se reproduce un canal del sintonizador TCL a pantalla completa:

- Azul: abre LOVEStv del canal actual.
- Amarillo: solicita «Ver desde inicio» al servicio de la emisora.
- Rojo en los canales de RTVE: abre el acceso interactivo de RTVE.
- Dentro de la sesión, Menú ofrece Continuar, Volver a Channel+ y Guardar informe.

La integración está limitada al motor ARM de 32 bits y la entrada com.tcl.tvinput/.TDTVInputService comprobados en la TCL G07. En otros sintonizadores, IPTV, VOD, multivista y reproducción de archivo, las teclas conservan su funcionamiento anterior. OK, Atrás, flechas y transporte del reproductor normal no se interceptan. Una pulsación de color se confirma al soltar; las repeticiones no crean actividades adicionales y salir de la actividad cancela la tecla pendiente.

No se requieren la APK independiente ni un lanzador oficial adicional. El cambio de identidad implica que las cookies del navegador pertenecen ahora a los datos de Channel+: el servicio puede pedir su consentimiento la primera vez. No se aceptan automáticamente cookies ni diálogos.

## Sesión y regreso

La actividad puente mantiene parado el reproductor principal durante la sesión y los cambios de canal. El onStop/onStart existente libera y restaura los motores. El puente espera al cierre del proceso de HbbTV antes de regresar. El motor TCL permanece en su proceso independiente com.tcl.tv, con el UID de Channel+, y sólo ese proceso se termina al cerrar. La aplicación principal omite la inicialización de Koin, reproductores y trabajos en el proceso del motor.

Al cerrar, el motor publica exclusivamente la entrada y el identificador del canal en un AtomicFile privado. Channel+ consume y elimina ese resultado, y resuelve el canal dentro del catálogo visible del perfil actual. El cambio usa la ruta normal de sintonización; no modifica listas ni cambia de perfil. El archivo no contiene cookies, claves, certificados ni direcciones IPTV.

Se conserva el comportamiento de la prueba 1.45: canales del mismo grupo, fondo del programa, paneles negros, columna de directo, selector y movimiento real del carrusel, RTVE encuadrado, adaptación de controles y saltos escalonados hasta ×32. Las limitaciones y la disponibilidad efectiva de cada contenido siguen dependiendo del servicio y del sintonizador.

## Funciones existentes conservadas

La 5.3.3 ya incluye la barra de información de 15 segundos con cierre por Atrás; puntuación IMDb y distintivos SVG de edad/contenido cuando están disponibles; metadatos Trakt y artwork TheTVDB; grupos de versiones TDT/IPTV con prioridad TDT/calidad; API de timeshift nativo; tamaño de HUD; carteles persistentes; logos sin fondo gris; vistas de canales y navegación de ajustes. Esta versión no vuelve a implementar esas funciones ni introduce migraciones de base de datos.

## Procedencia y reconstrucción del motor

Base independiente 1.45, SHA-256 9a7b1c375fbfe90453d697a12c060c763a985691b47c735327e6414a2054d8d8. Los assets y bibliotecas ARM se conservan sin cambios. Los smali del motor retenido están en tools/hbbtv/runtime-smali. Los cambios de contrato son los hooks de IntegrationSession en creación/teclas/cierre, el indicador integrado en el cambio de canal y la guardia que reconoce el paquete anfitrión tv.own.owntv.tdt2. Las identidades Java/JNI originales se conservan por compatibilidad del motor; no son el ID instalable de la aplicación.

El adaptador Java se compila y se superpone a los smali, se ensambla y se convierte a classes.jar para que AGP/D8/R8 lo incluyan por la ruta normal. El JAR precompilado está en app/libs/lovestv-runtime.jar. Las reglas de R8 conservan los contratos privados usados por reflexión y JNI. No se utiliza descarga de código, DexClassLoader ni modificación de la APK después de compilar.

Para regenerar el JAR:

```sh
HBBTV_TOOLS_DIR=/ruta/herramientas DEX2JAR_HOME=/ruta/dex-tools-v2.4 python3 tools/hbbtv/build_runtime.py
```

Herramientas: ECJ 3.33.0, Android SDK jar, D8 build-tools 35, smali/baksmali 2.5.2 y dex-tools 2.4. La compilación de la app usa JDK 21, Gradle 9.7.1 y el SDK/Build Tools declarados en el proyecto. La clave original permanece fuera de las fuentes y de Git.

## Comprobaciones

La configuración de actividades no exportadas, separación de proceso y XML de recursos se ha comprobado. El inventario de literales Kotlin pasa. La compilación release completa termina correctamente. Pasan 1.879 pruebas JVM: core 1.285, player-core 427 y app 167, incluidas cuatro pruebas nuevas de la política de acceso HbbTV. La APK contiene las 107 clases del motor retenido y 25 assets/bibliotecas idénticos a la 1.45. Firma v2, integridad ZIP, identidad/versión y alineación de 16 KiB verificadas. El certificado coincide criptográficamente con la APK 5.3.3 publicada: 801bde35b2bcefcfe4fa65348b59d8e9b7053600b88842116e22f1979724be2f. La nueva transición desde Channel+ y su regreso requieren comprobación física con el mando de la TCL.

APK SHA-256: b3117ae45fde6721aa866300f7dab951c8d268987acf2dd572dac9f893413669.

En entornos con 8 GiB, el empaquetado release se ha completado con --max-workers=1, heap Gradle de 4 GiB y -Pkotlin.compiler.execution.strategy=in-process. No se alteran las comprobaciones de lint para compilar.
