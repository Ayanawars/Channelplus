# Channel+ 5.3.6 TIF experiment (NOT a confirmed LOVEStv integration)

Starting point: Channel+ 5.3.5 sources; reference: LOVEStv test/design 1.45.

The original bridge was NOT acceptable for an in-player experience: `HbbTvEntryActivity` and `ProbeActivity` launched their own TDT TV input and browser, causing the old player to stop. The 5.3.5 handoff photo merely masked a player switch, and could not guarantee uninterrupted video.

## Experimental path

- For a fully screened TCL DVB/TDT channel, the Blue/Yellow broadcaster buttons (and Red on RTVE) are delivered **directly to the already tuned TvView** via `TvView.dispatchKeyEvent`. No new Activity, tuner, WebView, or HbbTV runtime is started.
- Android TV TIF can deliver KeyEvents to a TV input and optionally show its own broadcast interactive overlay. This is a platform ability, **not a guarantee the TCL TDT input exposes LOVEStv to third-party clients**.
- If a broadcaster key is queued, directional, OK and Menu keys are forwarded to the same TIF session. First short Back is sent to the tuner and resets the interception state so Channel+ returns to its normal remote/key behavior. Changing or leaving the channel also resets this state.
- If the TIF session reports the colour key unhandled, native mode is reset. Colour-key repeats do not launch repeated actions. IPTV, VOD, multiview and catalogue remain outside the interception.
- Old activity bridge components explicitly have `android:enabled="false"` in manifest. The original runtime is retained in sources, not invoked. No new TV-app permissions or disguised vendor identity are introduced.

## Testing on physical TCL is mandatory

1. Tune La 1 HD in Channel+, wait for picture+sound, press Blue once.
2. Observe whether a **real** LOVEStv overlay appears over Channel+'s existing video and whether audio remains playing. An Android `dispatchKeyEvent` success log only indicates queued input, not working HbbTV.
3. Try Right/Left, OK and Back. Check Channel+ channel switching immediately after Back.
4. Repeat on Cuatro or Telecinco, then try an IPTV channel (must not enter TIF interaction).
5. Save Android logcat filtered for `ChannelplusHbb`, including any `TCL tuner did not handle broadcaster key` lines. Confirm no new `HbbTvEntryActivity` or `ProbeActivity` is launched. This experiment is a failure if the tuner ignores the colour key or navigation breaks. Never substitute the old second-player bridge silently.

## Build status

Sources modified and static source assertions checked here. This environment has no Android SDK/Gradle distribution so the APK and on-device behavior are not verified. No release has been published and no signing material is included.
