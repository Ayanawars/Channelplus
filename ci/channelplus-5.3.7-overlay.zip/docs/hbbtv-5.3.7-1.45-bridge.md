# Channel+ 5.3.7 — Integración experimental LOVEStv 1.45 (TCL G07)

Objetivo: usar en el **reproductor TDT existente** de Channel+ la inicialización nativa que funcionó en LOVEStv 1.45 (incluyendo RTVE, Atresmedia y Mediaset). No abrir un segundo TvView, la app de TV TCL ni `ProbeActivity`; tampoco capturar un fotograma de la TV para simular continuidad.

## Qué se ha corregido

- El enlace al servicio y la superficie HbbTV se crean en cuanto Channel+ tiene la sesión TCL TDT, sin esperar al primer botón de color ni a que aparezca el vídeo. Esto evita el bloqueo circular de versiones anteriores.
- El motor nativo **sí espera la señal de vídeo** para ejecutar el arranque de 1.45: registro local del motor, carga de las bibliotecas de TCL y perfil/certificados, `HbbtvServer.init`, `Tbrowser.initTbrowser` y `HbbtvServer.start`. La pulsación azul no es un desencadenante del arranque.
- Los dos watchdogs de inicialización arrancan **cuando corresponde**, no mientras el sintonizador aún busca señal.
- `Back` se entrega primero al HbbTV: solo se libera el control y se oculta el navegador si el motor devuelve `handled=false`. Los cambios de canal siempre liberan la navegación. Las respuestas IPC antiguas por cambio de canal o solicitud se ignoran.
- Si un arranque falla, no se vuelve a intentar infinitamente sobre el mismo canal: un nuevo cambio real de sesión permite otro intento. El vídeo TDT sigue siendo independiente del navegador.
- Se conserva `standard` con su ABI habitual. Se añade **`hbbtv32`** para que esta TCL ejecute el motor JNI de TCL de 32 bits. Android determina la arquitectura al iniciar la aplicación, no de forma independiente para un `Service`.
- En **`hbbtv32`**, el propio reproductor de Channel+ y el motor nativo utilizan el mismo proceso local de 32 bits `com.tcl.tv` (sin compartir UID con la app del fabricante). Se registra una referencia débil a la **Activity real que ya contiene el TvView** y `initTbrowser` recibe esa Activity. Es el tipo de Context que usaba la prueba 1.45 y evita depender de un `Context` de Service. No se abre otra Activity, ni otro sintonizador.
- Se ha protegido la liberación del motor para que nunca termine el proceso que contiene la Activity principal de Channel+ al salir de LOVEStv.
- La variante tiene `versionCode=100018`, superior a las versiones 5.3.6 de prueba.

## Archivos

En la raíz del proyecto 5.3.6 original, sustituir los archivos de este parche respetando sus carpetas; en el ZIP también hay un `.patch` para revisión. El jar del runtime original 1.45 y las bibliotecas nativas no se modifican.

## Validación estática

Desde la raíz del proyecto:

```sh
python tools/hbbtv/verify_channelplus_145.py
```

## Compilar en Windows

Con el Android SDK de la versión del proyecto y Gradle configurados:

```bat
cd owntv_tdt
gradlew.bat :app:assembleHbbtv32Debug
```

**Importante:** para actualizar la aplicación instalada sin borrar datos hay que firmar con su certificado original. No se adjuntan claves privadas. Un APK debug de otro certificado no instala encima de la versión actual. La configuración de release debe usar el keystore original, no el de CI.

## Prueba física (pendiente)

1. Instalar el APK `hbbtv32` firmado con la clave adecuada; sintonizar **La 1 TDT en pantalla completa**.
2. Esperar 15–25 segundos **sin pulsar azul**. Debe aparecer el aviso nativo del servicio si el navegador es compatible. La imagen y el audio del canal no deben interrumpirse.
3. Pulsar Azul, navegar con flechas/OK, probar Atrás y después cambiar de canal. Repetir con Atresmedia y Mediaset. En IPTV no debe levantarse el motor.
4. Con Bugjaeger recopilar `logcat -d -s ChannelplusHbb:* *:S`. La secuencia esperada es `Runtime attach: bitness=32`, `Tbrowser context=Channel+ Activity (1.45-compatible)`, `...picture ready`, `Autostart`, `HbbtvServer.init`, `HbbtvServer.start`. El valor del estado, por sí solo, no prueba el funcionamiento del navegador.

## Límite técnico aún no verificado

La prueba original 1.45 ejecutaba `Tbrowser.initTbrowser(Activity, root, false)` con **una Activity real**. La variante `hbbtv32` conserva esa condición: el servicio de HbbTV obtiene la Activity activa de Channel+ **en su mismo proceso** y crea la superficie embebida sobre el `TvView` existente. Así no se necesita una Activity adicional ni reiniciar el sintonizador. Aunque se conserva el contexto que funcionó en 1.45, **no está probado todavía que el navegador TCL acepte dibujar dentro de `SurfaceControlViewHost`**; también hay que validar cómo reacciona el motor a cambios de canal desde Channel+ y posibles regresiones por usar un proceso distinto en esta variante. Si hay `ClassCastException`, `SecurityException`, rechazo de registro o pantalla negra, revisar el log en el TV antes de otro cambio. **No afirmar que ya funciona en la TCL hasta la prueba real.**

Este parche incluye fuentes modificadas, no un APK nuevo probado, porque no se pudo descargar Gradle 9.7.1 ni invocar el Android SDK desde el entorno de edición.
