# Channel+ 5.3.6 HbbTV autostart experiment

Package tv.own.owntv.tdt2, versionCode 100016, versionName 5.3.6-hbb-autostart.

The TIF colour-key experiment received unhandled callbacks on TCL G07. This
revision starts the existing 1.45 runtime when the current fullscreen TCL tuner
reports video available. Pressing a colour key is no longer the startup trigger.

HbbTvPlayerView owns the SAME TvView formerly created by ExoPreviewSurface.
TifPlayback publishes its input, channel, video readiness and tune generation.
The player binds a non-exported same-UID HbbTvRuntimeService in its existing
com.tcl.tv runtime process. This is the app's process, not TCL TV's UID.
The service reuses the existing 1.45 registration and native initialization;
it creates Tbrowser in a transparent SurfaceControlViewHost (Android 11+).
The SurfacePackage is embedded above the original tuner. No new tuner, Activity,
snapshot handoff, external TV app, or channel database writes are used.

The native sequence is registration, vendor browser preparation, HbbtvServer JNI
load, existing certificate/UA preparation, HbbtvServer.init, initTbrowser callback,
then HbbtvServer.start. A current TDT channel is required. Runtime startup logs
are separate from broadcaster getState and handled-key results. init/start return
values and compilation do NOT establish working LOVEStv.

The remote native process is bounded by startup timeouts. Failure hides the
browser surface and unbinds it while leaving TDT playback active. Navigation is
captured only after an accepted colour key. Back releases capture; channel
changes and signal loss reject stale acknowledgements. Tests cover these IPC
ordering cases. The old TIF navigation relay is removed.

Physical validation pending: TCL Tbrowser must accept a window Context with a
ViewGroup instead of ProbeActivity's Activity. If it casts to Activity, startup
will fail explicitly with a stack trace under ChannelplusHbb. A service-created
browser surface, broadcaster discovery, native video/control integration, and
the rendering/navigation behavior must be checked on the actual TV. The custom
1.45 Activity-based DOM adaptations are retained in the archive but are not
silently claimed to be active in this service renderer.

Device check: install as an update, open a TDT channel fullscreen and wait 15–25
seconds WITHOUT pressing a colour key. Read logcat -d -s ChannelplusHbb. Startup
must already appear before a key is pressed. Then check the broadcaster prompt,
blue/red, navigation, Back, channel changes, and return from background. Verify
video/audio continue through the startup. IPTV must not start this service.
