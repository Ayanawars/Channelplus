package tv.own.channelplus.lovestvprobe;

import android.app.Activity;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/** Thin integration adapter around the verified 1.45 runtime; no synthetic OK or consent. */
public final class IntegrationSession implements Runnable {
    private static final WeakHashMap<Activity, IntegrationSession> sessions = new WeakHashMap<>();
    private final WeakReference<Activity> owner;
    private final int key;
    private final long started = SystemClock.elapsedRealtime();
    private boolean initialized;
    private long readyAt;
    private boolean done;
    private View frame;
    private IntegrationSession(Activity activity, int action) { owner = new WeakReference<>(activity); key = action; }

    public static void attach(Activity activity) {
        if (!activity.getIntent().getBooleanExtra("integrated", false)) return;
        IntegrationSession session = new IntegrationSession(activity, activity.getIntent().getIntExtra("initial_key", 186));
        sessions.put(activity, session);
        session.hideControls(activity);
        try {
            session.frame = (View) Class.forName("tv.own.owntv.features.hbbtv.HbbTvHandoff")
                    .getMethod("showFrame", Activity.class, ViewGroup.class)
                    .invoke(null, activity, (ViewGroup) field(activity, "root"));
        } catch (Exception failure) { android.util.Log.d("ChannelplusHbb", "No handoff frame", failure); }
        activity.getWindow().getDecorView().postDelayed(session, 100);
    }
    private static Object field(Activity activity, String name) throws Exception {
        Field field = activity.getClass().getDeclaredField(name); field.setAccessible(true); return field.get(activity);
    }
    private static boolean yes(Activity activity, String name) throws Exception { return Boolean.TRUE.equals(field(activity, name)); }
    private static Object call(Activity activity, String name) throws Exception {
        Method method = activity.getClass().getDeclaredMethod(name); method.setAccessible(true); return method.invoke(activity);
    }
    private void hideControls(Activity activity) {
        try {
            ((View) field(activity, "controls")).setVisibility(View.GONE);
            Field capture = activity.getClass().getDeclaredField("captureKeys"); capture.setAccessible(true); capture.setBoolean(activity, true);
        } catch (Exception failure) { android.util.Log.w("ChannelplusHbb", "Controls not ready", failure); }
    }
    @Override public void run() {
        Activity activity = owner.get();
        if (done || activity == null || activity.isFinishing() || activity.isDestroyed()) return;
        if (SystemClock.elapsedRealtime() - started > 60000) {
            done = true; removeFrame(); activity.finish(); return;
        }
        try {
            if (yes(activity, "closed")) return;
            if (yes(activity, "videoReady")) removeFrame();
            else if (SystemClock.elapsedRealtime() - started > 20000) {
                done = true; removeFrame(); activity.finish(); return;
            }
            // GroupOpen already owns the initial blue action.
            if (key == 186) {
                if (yes(activity, "videoReady")) { done = true; return; }
                activity.getWindow().getDecorView().postDelayed(this, 100);
                return;
            }
            if (!yes(activity, "started")) {
                if (!initialized && yes(activity, "videoReady") && !yes(activity, "starting")) {
                    initialized = true; call(activity, "initialize");
                }
            } else {
                if (readyAt == 0) readyAt = SystemClock.elapsedRealtime();
                if (activity.hasWindowFocus() && SystemClock.elapsedRealtime() - readyAt >= 5000) {
                    done = true; hideControls(activity);
                    // The native handlers own readiness, key mapping and trusted browser delivery.
                    activity.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, key));
                    activity.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, key));
                    return;
                }
            }
        } catch (Exception failure) {
            done = true; android.util.Log.e("ChannelplusHbb", "Initial action failed", failure); return;
        }
        activity.getWindow().getDecorView().postDelayed(this, 250);
    }
    private void removeFrame() {
        if (frame == null) return;
        View old = frame; frame = null;
        old.postDelayed(() -> {
            if (old.getParent() instanceof ViewGroup) ((ViewGroup) old.getParent()).removeView(old);
        }, 80);
    }
    public static boolean key(Activity activity, KeyEvent event) {
        IntegrationSession session = sessions.get(activity);
        if (session != null && event.getKeyCode() == KeyEvent.KEYCODE_MENU) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                try {
                    Class.forName("tv.own.owntv.features.hbbtv.HbbTvMenu").getMethod("show", Activity.class).invoke(null, activity);
                } catch (Exception failure) { android.util.Log.w("ChannelplusHbb", "Menu unavailable", failure); }
            }
            return true;
        }
        if (session == null || session.done || session.key == 186) return false;
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK || event.getKeyCode() == KeyEvent.KEYCODE_HOME) {
            session.done = true;
            if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) { activity.finish(); return true; }
        }
        return false;
    }
    public static void closed(Activity activity) {
        IntegrationSession session = sessions.remove(activity);
        if (session != null) { session.done = true; activity.getWindow().getDecorView().removeCallbacks(session); }
        if (activity.getIntent().getBooleanExtra("integrated", false)) {
            android.util.AtomicFile file = new android.util.AtomicFile(new java.io.File(activity.getFilesDir(), "hbbtv-return.json"));
            java.io.FileOutputStream output = null;
            try {
                org.json.JSONObject result = new org.json.JSONObject();
                result.put("input", activity.getIntent().getStringExtra("input"));
                result.put("id", activity.getIntent().getLongExtra("id", -1));
                output = file.startWrite();
                output.write(result.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
                file.finishWrite(output);
            } catch (Exception failure) { file.failWrite(output); android.util.Log.w("ChannelplusHbb", "Return channel unavailable", failure); }
        }
    }
}
