#!/usr/bin/env python3
"""Rebuild only the Java integration adapter, retaining the verified runtime classes."""
import os,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
java=Path(os.environ['JAVA_HOME'])/'bin'
android=Path(os.environ['ANDROID_HOME'])/'platforms/android-37.0/android.jar'
with tempfile.TemporaryDirectory(prefix='hbbtv-adapter-') as d:
    subprocess.run([str(java/'javac'),'-source','8','-target','8','-classpath',str(android),'-d',d,str(root/'tools/hbbtv/IntegrationSession.java')],check=True)
    subprocess.run([str(java/'jar'),'uf',str(root/'owntv_tdt/app/libs/lovestv-runtime.jar'),'-C',d,'.'],check=True)
