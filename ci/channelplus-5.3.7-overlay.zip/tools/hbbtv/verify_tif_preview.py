#!/usr/bin/env python3
"""Source-only regression checks for the experimental in-player HbbTV path."""
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[2]
read = lambda x: (root/x).read_text(encoding='utf-8')
shell=read('owntv_tdt/app/src/main/java/tv/own/owntv/features/shell/OwnTVShell.kt')
tif=read('owntv_core_tdt/player-core/src/main/java/tv/own/owntv/player/TifPlayback.kt')
preview=read('owntv_core_tdt/player-core/src/main/java/tv/own/owntv/player/LivePreviewEngine.kt')
launcher=read('owntv_tdt/app/src/main/java/tv/own/owntv/features/hbbtv/HbbTvLauncher.java')
assert 'HbbTvLauncher.handle(' not in shell
assert 'HbbTvLauncher.prepare(' not in shell
assert 'forwardTunerInteractiveKey(event, activation)' in shell
assert 'supportedInPlayer(tif.inputId, tif.channelId)' in shell
assert 'isTunerInteractiveMode' in shell
assert 'target.dispatchKeyEvent(KeyEvent(event))' in tif
assert 'fun forwardInteractiveKey(event: KeyEvent, activation: Boolean)' in tif
assert 'leaveInteractiveMode()' in tif and 'old.setOnUnhandledInputEventListener(null)' in tif
assert 'fun play(next: TifChannelUri) { leaveInteractiveMode()' in tif
assert 'fun stop() { leaveInteractiveMode()' in tif
assert 'fun forwardTunerInteractiveKey' in preview
assert 'boolean supportedInPlayer' in launcher
manifest=ET.fromstring(read('owntv_tdt/app/src/main/AndroidManifest.xml'))
android='{http://schemas.android.com/apk/res/android}'
activity_names=['tv.own.owntv.features.hbbtv.HbbTvEntryActivity','tv.own.channelplus.lovestvprobe.ProbeActivity','tv.own.channelplus.lovestvprobe.ChannelSwitchActivity']
for n in activity_names:
    nodes=[node for node in manifest.findall('.//activity') if node.get(android+'name') == n]
    assert len(nodes) == 1 and nodes[0].get(android+'enabled') == 'false', n
service=[node for node in manifest.findall('.//service') if node.get(android+'name') == 'tv.own.owntv.features.hbbtv.HbbTvWarmupService']
assert len(service)==1 and service[0].get(android+'enabled') == 'false'
assert '5.3.6-tif-preview' in read('owntv_tdt/app/build.gradle.kts')
print('PASS: native TIF in-player route; legacy player disabled; mode cleanup; manifest XML; preview version')
