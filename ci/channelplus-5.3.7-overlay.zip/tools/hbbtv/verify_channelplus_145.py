#!/usr/bin/env python3
"""Static regression checks for the Channel+ / TCL LOVEStv 1.45 integration.
No Android SDK needed. Physical playback and vendor-native startup are NOT tested.
"""
from pathlib import Path
from hashlib import sha256
import re

base = Path(__file__).resolve().parents[2]
read = lambda relative: (base / relative).read_text()
player = read('owntv_tdt/app/src/main/java/tv/own/owntv/features/hbbtv/HbbTvPlayerView.java')
service = read('owntv_tdt/app/src/main/java/tv/own/channelplus/lovestvprobe/HbbTvRuntimeService.java')
abi = read('owntv_tdt/app/build.gradle.kts')
protocol = read('owntv_tdt/app/src/main/java/tv/own/owntv/features/hbbtv/HbbTvProtocol.java')
preview = read('owntv_tdt/app/src/main/java/tv/own/owntv/player/MpvVideoSurface.kt')

assert 'new TvView(context)' in player and 'getTvView()' in player
assert 'engine.attachTvInputView(tvView)' in preview
assert '!enabled || !surfaceReady' in player  # not blocked by !ready
assert '!enabled || !ready || !surfaceReady' not in player
assert 'if(ready) initialize()' in service
assert 'if(connection!=null && attached && ready && !started)' in player
assert 'initTbrowser' in service and 'HbbtvServer.start' in service
assert 'Process.is64Bit()' in service
assert 'HbbTvActivityHost.current()' in service
assert 'playerActivity!=null ? playerActivity' in service
assert 'HbbTvActivityHost.attach(activity)' in player
assert 'HbbTvActivityHost.detach(activity)' in player
assert 'android:process="com.tcl.tv"' in read('owntv_tdt/app/src/hbbtv32/AndroidManifest.xml')
assert 'create("hbbtv32")' in abi
assert re.search(r'create\("hbbtv32"\).*?abiFilters \+= listOf\("armeabi-v7a"\)', abi, re.S)
assert '"100018"' in abi
assert 'case KEY_RESULT:' in player and 'KEYCODE_BACK' in player
assert '!data.getBoolean(ACCEPTED)' in player
assert 'getLong(KEY_EPOCH)==gate.epoch()' in player
assert 'if(code==KeyEvent.KEYCODE_BACK) { gate.leave();' not in player
assert 'new TvView' not in service
assert 'startActivity(' not in service and 'startActivity(' not in player
assert 'android:exported="false" android:process="com.tcl.tv"' in read('owntv_tdt/app/src/main/AndroidManifest.xml')
assert 'SURFACE_PACKAGE' in protocol and 'VIDEO_READY' in protocol

artifacts={
    'owntv_tdt/app/src/main/jniLibs/armeabi-v7a/libsectionprobe.so': '399d2ad33c4cb4ffa4e29c6b083f2e7f0af6313273761dafaa0bf73bfdad6cc6',
    'owntv_tdt/app/src/main/jniLibs/armeabi-v7a/libuaprofile.so': '98c24795c9180dca72201c2cadd3f1e9c87c790c7c41615527c1ef557e8b5a2b',
    'owntv_tdt/app/libs/lovestv-runtime.jar': '3063fff3098e91b13ac457cb6a4e80aed4cd29b9e7afb3a8f58928cf71c65832',
}
for path, expected in artifacts.items():
    target=base/path
    assert target.is_file(), f'Runtime 1.45 missing: {path}'
    assert sha256(target.read_bytes()).hexdigest()==expected, f'Unexpected runtime binary: {path}'
print('OK: 1.45 runtime preserved; 32-bit flavor; startup without colour key; tuner and Back guards.')
print('PENDING: Gradle compilation, TCL 32-bit runtime, native browser and broadcast video on the TV.')
