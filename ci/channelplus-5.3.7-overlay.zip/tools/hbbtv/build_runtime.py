#!/usr/bin/env python3
"""Rebuild the retained 1.45 JVM runtime from auditable smali and the integration adapter.

HBBTV_TOOLS_DIR: android.jar, ecj.jar, smali/*.jar, buildtools/android-15/lib/d8.jar.
DEX2JAR_HOME: dex-tools-v2.4 release folder. No signing material is read here.
"""
import os,shutil,subprocess,tempfile
from pathlib import Path

base=Path(__file__).resolve().parent
tools=Path(os.environ['HBBTV_TOOLS_DIR']).resolve()
dex2jar=Path(os.environ['DEX2JAR_HOME']).resolve()
android=tools/'android.jar'
def run(*args): subprocess.run([str(a) for a in args],check=True)
with tempfile.TemporaryDirectory(prefix='channelplus-hbb-') as tmp:
    w=Path(tmp)
    run('java','-jar',tools/'ecj.jar','-1.8','-proc:none','-bootclasspath',android,
        '-d',w/'classes',base/'IntegrationSession.java')
    (w/'dex').mkdir()
    run('java','-cp',tools/'buildtools/android-15/lib/d8.jar','com.android.tools.r8.D8',
        '--min-api','26','--lib',android,'--output',w/'dex',*(w/'classes').rglob('*.class'))
    run('java','-cp',str(tools/'smali/*'),'org.jf.baksmali.Main','disassemble',w/'dex/classes.dex','-o',w/'extra')
    shutil.copytree(base/'runtime-smali',w/'smali')
    for p in (w/'extra').rglob('*.smali'):
        target=w/'smali'/p.relative_to(w/'extra');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    run('java','-cp',str(tools/'smali/*'),'org.jf.smali.Main','assemble',w/'smali','-o',w/'runtime.dex')
    target=base.parent.parent/'owntv_tdt/app/libs/lovestv-runtime.jar'
    target.parent.mkdir(exist_ok=True)
    run(dex2jar/'d2j-dex2jar.sh','--force',w/'runtime.dex','-o',target)
