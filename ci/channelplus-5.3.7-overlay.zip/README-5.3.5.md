# Channel+ 5.3.5 — HbbTV

Fuentes basadas en 5.3.4. Preparación del proceso aislado al ver TDT durante 1,5 s,
sin inicializar JNI ni ocupar el sintonizador. Entrada sin mensaje puente, con
captura temporal del último fotograma mediante PixelCopy. Se libera primero el
reproductor principal y después se inicia la sesión TCL. El fotograma desaparece
cuando TCL confirma vídeo. Si la TV impide capturar su superficie, la apertura
continúa pero no se garantiza ocultar el negro de la resintonización.

La captura espera como máximo 700 ms; la liberación, 1,5 s; la disponibilidad de
vídeo, 20 s. Si no llega vídeo, vuelve a Channel+. Se conserva GroupOpen para el
azul y las rutas existentes de rojo y amarillo. El motor smali permanece intacto.

Reconstruir adaptador: JAVA_HOME y ANDROID_HOME configurados,
`python3 tools/hbbtv/update_adapter.py`. Compilar app con JDK 21, Gradle 9.7.1,
Android SDK 37.0 y Build Tools 37.0.0. Firma original externa a las fuentes.

Compilación release completa y firma compatible verificadas. Cuatro pruebas de política de botones correctas.
La transición y la captura necesitan comprobación física en la TCL.
