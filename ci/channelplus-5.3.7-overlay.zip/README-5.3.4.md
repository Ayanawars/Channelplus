# Channel+ 5.3.4

Código 100013, paquete tv.own.owntv.tdt2. Actualización compatible sobre 5.3.3 o anteriores con la firma original.

Integra el motor LOVEStv/RTVE de la prueba 1.45 dentro de Channel+. En un canal TDT TCL a pantalla completa: azul abre LOVEStv; amarillo solicita ver desde inicio; rojo abre RTVE en sus canales. Menú permite continuar, volver a Channel+ o guardar un informe. Mantiene el diseño, selector, accesos de grupo y saltos hasta ×32. La sesión del navegador usa un proceso separado y vuelve al reproductor principal.

Se conservan los cambios de la instantánea publicada 5.3.3: barra de 15 segundos y cierre con Atrás, metadatos y distintivos, agrupación TDT/IPTV, timeshift nativo, logos y carteles, interfaz de canales/guía y ajustes.

Las fuentes exactas están en este archivo, incluyendo los proyectos app/core/player, smali y adaptador Java del motor retenido, assets, bibliotecas ARM precompiladas y JAR reproducible del adaptador. Las dependencias externas se resuelven como indica el proyecto. No se incluyen claves de firma ni datos de la TV. La firma original debe configurarse desde una ubicación privada para generar una actualización compatible.

Validación: compilación release y 1.879 pruebas unitarias correctas; firma compatible con la 5.3.3 publicada; integridad y alineación verificadas. Falta comprobar físicamente en la TCL la entrada, cambio de canal y regreso desde la integración.

Detalles y reconstrucción en docs/hbbtv-5.3.4.md. Esta es una compilación local; no se ha publicado una nueva versión en GitHub.
