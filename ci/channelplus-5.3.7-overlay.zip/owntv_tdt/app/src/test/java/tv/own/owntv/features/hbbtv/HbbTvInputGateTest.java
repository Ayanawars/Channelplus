package tv.own.owntv.features.hbbtv;
import org.junit.Test;
import static org.junit.Assert.*;

public class HbbTvInputGateTest {
    @Test public void queuedKeyDoesNotCaptureUntilRuntimeAccepts() {
        HbbTvInputGate gate=new HbbTvInputGate(); gate.channel(1,true);
        long request=gate.beginColour(); assertFalse(gate.interactive());
        gate.accepted(1,request,false); assertFalse(gate.interactive());
        request=gate.beginColour(); gate.accepted(1,request,true); assertTrue(gate.interactive());
    }
    @Test public void backWinsAgainstDelayedPositiveReply() {
        HbbTvInputGate gate=new HbbTvInputGate(); gate.channel(1,true);
        long request=gate.beginColour(); gate.leave(); gate.accepted(1,request,true); assertFalse(gate.interactive());
    }
    @Test public void channelAndVideoLossRejectOldReply() {
        HbbTvInputGate gate=new HbbTvInputGate(); gate.channel(1,true);
        long request=gate.beginColour(); gate.channel(2,true); gate.accepted(1,request,true); assertFalse(gate.interactive());
        request=gate.beginColour(); gate.channel(2,false); gate.channel(2,true);
        gate.accepted(2,request,true); assertFalse(gate.interactive());
    }
    @Test public void latestColourReplyOwnsNavigation() {
        HbbTvInputGate gate=new HbbTvInputGate(); gate.channel(4,true);
        long old=gate.beginColour(), latest=gate.beginColour();
        gate.accepted(4,latest,false); gate.accepted(4,old,true); assertFalse(gate.interactive());
    }
}
