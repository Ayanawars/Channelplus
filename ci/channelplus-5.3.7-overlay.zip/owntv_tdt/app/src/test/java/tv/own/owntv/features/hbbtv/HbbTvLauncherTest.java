package tv.own.owntv.features.hbbtv;

import org.junit.Test;
import static org.junit.Assert.*;

public class HbbTvLauncherTest {
    private static final String TCL = "com.tcl.tvinput/.TDTVInputService/HW1413742848";
    @Test public void onlyTheTestedNativeTclInputCanLaunch() {
        assertTrue(HbbTvLauncher.supported(TCL, 155, false, true));
        assertFalse(HbbTvLauncher.supported("https://example.test/stream.m3u8", 155, false, true));
        assertFalse(HbbTvLauncher.supported("com.example.iptv/.TvInputService/1", 155, false, true));
        assertFalse(HbbTvLauncher.supported("com.tcl.tvinput/.TDTVInputServiceFake/1", 155, false, true));
        assertFalse(HbbTvLauncher.supported(null, 155, false, true));
        assertFalse(HbbTvLauncher.supported(TCL, -1, false, true));
    }
    @Test public void missingOrWrongAbiRuntimeLeavesNormalPlaybackAlone() {
        assertFalse(HbbTvLauncher.supported(TCL, 155, true, true));
        assertFalse(HbbTvLauncher.supported(TCL, 155, false, false));
    }
    @Test public void blueAndYellowAreBroadcasterActionsAndTransportKeysAreUntouched() {
        for (String channel : new String[]{"Telecinco", "Cuatro HD", "Antena 3", "MEGA", "La 1 HD"}) {
            assertTrue(HbbTvLauncher.accepts(186, channel));
            assertTrue(HbbTvLauncher.accepts(185, channel));
            assertFalse(HbbTvLauncher.accepts(23, channel));
            assertFalse(HbbTvLauncher.accepts(4, channel));
            assertFalse(HbbTvLauncher.accepts(184, channel));
            assertFalse(HbbTvLauncher.accepts(90, channel));
        }
    }
    @Test public void redIsOnlyInterceptedForRtveIncludingBroadcastQualitySuffixes() {
        for (String channel : new String[]{"La 1", "La 2 HD", "TVE 1 UHD", "Canal 24 Horas", "Clan TVE", "Teledeporte HD"})
            assertTrue(channel, HbbTvLauncher.accepts(183, channel));
        for (String channel : new String[]{"Telecinco", "Cuatro", "Antena 3", "La Sexta", "MEGA", "Nova", "La 10"})
            assertFalse(channel, HbbTvLauncher.accepts(183, channel));
        assertFalse(HbbTvLauncher.accepts(183, null));
    }
    @Test public void nativeInPlayerDoesNotRequireVendorRuntimeAndRejectsNonTclInputs() {
        assertTrue(HbbTvLauncher.supportedInPlayer(TCL, 155));
        assertFalse(HbbTvLauncher.supportedInPlayer(TCL, -1));
        assertFalse(HbbTvLauncher.supportedInPlayer("com.tcl.tvinput/.Other/1", 155));
        assertFalse(HbbTvLauncher.supportedInPlayer("https://example.test/live.ts", 155));
        assertFalse(HbbTvLauncher.supportedInPlayer(null, 155));
    }
}