package tv.own.owntv.features.hbbtv;

import android.app.Activity;
import android.content.Intent;
import android.os.Process;
import android.view.KeyEvent;
import java.io.File;
import java.text.Normalizer;
import java.util.Locale;
import java.util.WeakHashMap;

/** Main-process entry only. The vendor engine never runs in Channel+'s player process. */
public final class HbbTvLauncher {
    private static final WeakHashMap<Activity, Integer> armed = new WeakHashMap<>();
    private static long lastWarmup;
    private HbbTvLauncher() {}

    public static void cancel(Activity activity) { armed.remove(activity); HbbTvHandoff.cancel(activity); }

    public static void prepare(Activity activity, String input, long id) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (!activity.hasWindowFocus() || (lastWarmup != 0 && now - lastWarmup < 60000) ||
                !supported(input, id, Process.is64Bit(), new File("/product/framework/com.tcl.hbbtv.jar").isFile())) return;
        try {
            activity.startService(new Intent(activity, HbbTvWarmupService.class));
            lastWarmup = now;
        } catch (RuntimeException unavailable) {
            android.util.Log.d("ChannelplusHbb", "Warmup deferred until color key", unavailable);
        }
    }

    public static final class ReturnedChannel {
        public final String input;
        public final long id;
        ReturnedChannel(String input, long id) { this.input = input; this.id = id; }
    }
    public static ReturnedChannel takeReturn(Activity activity) {
        android.util.AtomicFile file = new android.util.AtomicFile(new File(activity.getFilesDir(), "hbbtv-return.json"));
        if (!file.getBaseFile().exists()) return null;
        try {
            org.json.JSONObject result = new org.json.JSONObject(new String(file.readFully(), java.nio.charset.StandardCharsets.UTF_8));
            String input = result.getString("input"); long id = result.getLong("id");
            if (id >= 0 && input.startsWith("com.tcl.tvinput/.TDTVInputService/")) return new ReturnedChannel(input, id);
        } catch (Exception failure) { android.util.Log.w("ChannelplusHbb", "Return channel unavailable", failure); }
        finally { file.delete(); }
        return null;
    }

    public static boolean isRuntimeProcess(android.content.Context context) {
        if (android.os.Build.VERSION.SDK_INT >= 28) return "com.tcl.tv".equals(android.app.Application.getProcessName());
        android.app.ActivityManager manager = (android.app.ActivityManager) context.getSystemService(android.content.Context.ACTIVITY_SERVICE);
        if (manager != null && manager.getRunningAppProcesses() != null) {
            for (android.app.ActivityManager.RunningAppProcessInfo process : manager.getRunningAppProcesses()) {
                if (process.pid == Process.myPid()) return "com.tcl.tv".equals(process.processName);
            }
        }
        return false;
    }

    static boolean supported(String input, long id, boolean process64, boolean runtimePresent) {
        return id >= 0 && input != null && input.startsWith("com.tcl.tvinput/.TDTVInputService/") && !process64 && runtimePresent;
    }

    public static boolean accepts(int key, String label) {
        if (key == KeyEvent.KEYCODE_PROG_BLUE || key == KeyEvent.KEYCODE_PROG_YELLOW) return true;
        if (key != KeyEvent.KEYCODE_PROG_RED || label == null) return false;
        String name = Normalizer.normalize(label, Normalizer.Form.NFD).replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "")
                .replaceAll("(4k|uhd|fhd|hd|sd)$", "");
        return name.matches("(la1|la2|tve1|tve2|canal24horas|24horas|24h|clan|clantve|teledeporte|tdp)");
    }

    /** The in-player path needs only the active TCL TIF channel, not the 32-bit
     * vendor browser runtime. The legacy Activity bridge is deliberately unused. */
    public static boolean supportedInPlayer(String input, long id) {
        return id >= 0 && input != null && input.startsWith("com.tcl.tvinput/.TDTVInputService/");
    }

    public static boolean handle(Activity activity, KeyEvent event, String input, long id, String label) {
        if (HbbTvHandoff.pending(activity)) {
            if (accepts(event.getKeyCode(), label)) return true;
            if (event.getAction() == KeyEvent.ACTION_DOWN) HbbTvHandoff.cancel(activity);
        }
        if (!accepts(event.getKeyCode(), label) ||
                !supported(input, id, Process.is64Bit(), new File("/product/framework/com.tcl.hbbtv.jar").isFile())) return false;
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (event.getRepeatCount() == 0) armed.put(activity, event.getKeyCode());
            return true;
        }
        if (event.getAction() != KeyEvent.ACTION_UP) return true;
        Integer key = armed.remove(activity);
        if (key == null || key != event.getKeyCode() || event.isCanceled() || !activity.hasWindowFocus()) return true;
        Intent intent = new Intent(activity, HbbTvEntryActivity.class);
        intent.putExtra("input", input).putExtra("id", id).putExtra("label", label)
                .putExtra("initial_key", key);
        HbbTvHandoff.launch(activity, intent);
        return true;
    }
}
