package tv.own.channelplus.lovestvprobe;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.os.*;
import android.os.Process;
import android.util.Log;
import android.view.*;
import android.widget.FrameLayout;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import static tv.own.owntv.features.hbbtv.HbbTvProtocol.*;

/**
 * Runs 1.45's startup against the already tuned Channel+ session. Its browser is
 * embedded through SurfaceControlViewHost; no Activity or second TvView is opened.
 * TCL window-context compatibility is reported explicitly, not assumed successful.
 */
@android.annotation.TargetApi(30)
public final class HbbTvRuntimeService extends Service {
    private static final String TAG="ChannelplusHbb";
    private static int liveServices;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Messenger inbox=new Messenger(new Handler(Looper.getMainLooper(),this::receive));
    private final Map<Integer,Integer> keys=new HashMap<>();
    private Messenger client;
    private SurfaceControlViewHost viewHost;
    private FrameLayout root;
    private Context windowContext;
    private Object engine,browser,initListener;
    private int session;
    private long generation,channelId;
    private boolean closed,running,ready,initializing,hidden,browserPrepared;
    private String lastState;
    private final Runnable timeout=()->{ if(!running && !closed) fail("Browser initialization timed out",null); };
    private final Runnable inspect=new Runnable() {
        @Override public void run() {
            if(closed || !running) return;
            try {
                String state=String.valueOf(call(engine,"getState"));
                if(!state.equals(lastState)) {
                    Log.d(TAG,"Broadcaster state="+state+" channel="+channelId); lastState=state;
                }
            } catch(ReflectiveOperationException error) { Log.d(TAG,"Broadcaster state unavailable",error); }
            main.postDelayed(this,2000);
        }
    };
    @Override public void onCreate() { super.onCreate(); liveServices++; }
    @Override public IBinder onBind(Intent intent) { return Build.VERSION.SDK_INT>=30 ? inbox.getBinder() : null; }
    private boolean receive(Message message) {
        if(closed || message.replyTo==null || message.sendingUid!=Process.myUid()) return true;
        Bundle data=message.getData();
        if(message.what==ATTACH) {
            if(viewHost==null) attach(message.replyTo,data);
            return true;
        }
        if(client==null || !client.getBinder().equals(message.replyTo.getBinder()) || data.getInt(SESSION)!=session) return true;
        switch(message.what) {
            case CHANNEL:
                long next=data.getLong(GENERATION);
                if(generation!=next || channelId!=data.getLong(CHANNEL_ID)) {
                    hidden=false; lastState=null;
                    Log.d(TAG,"HbbTV follows existing tuner channel="+data.getLong(CHANNEL_ID));
                }
                boolean wasReady=ready;
                generation=next; channelId=data.getLong(CHANNEL_ID); ready=data.getBoolean(VIDEO_READY);
                visibility();
                if(!wasReady && ready) Log.i(TAG,"TCL tuner picture ready; native HbbTV initialization may begin channel="+channelId);
                if(ready && browserPrepared && !running) browserReady();
                else if(ready && !initializing && !running) initialize();
                break;
            case RESIZE:
                if(viewHost!=null) viewHost.relayout(Math.max(1,data.getInt(WIDTH)),Math.max(1,data.getInt(HEIGHT)));
                break;
            case KEY: key(data); break;
            case HIDE: hidden=true; visibility(); break;
            default: break;
        }
        return true;
    }
    private void attach(Messenger target,Bundle data) {
        client=target; session=data.getInt(SESSION);
        generation=data.getLong(GENERATION); channelId=data.getLong(CHANNEL_ID); ready=data.getBoolean(VIDEO_READY);
        String input=data.getString(INPUT_ID,"");
        Log.i(TAG,"Runtime attach: bitness="+(Process.is64Bit()?"64":"32")+
                " process="+android.app.Application.getProcessName()+" input="+input+
                " channel="+channelId+" videoReady="+ready);
        if(Process.is64Bit() || channelId<0 || !input.startsWith("com.tcl.tvinput/.TDTVInputService/")) {
            fail("TCL runtime needs a 32-bit process and the native TCL DVB/TDT input",null); return;
        }
        try {
            Display display=getSystemService(DisplayManager.class).getDisplay(data.getInt(DISPLAY));
            if(display==null) throw new IllegalStateException("Player display unavailable");
            android.app.Activity playerActivity=tv.own.owntv.features.hbbtv.HbbTvActivityHost.current();
            boolean activityProcess="com.tcl.tv".equals(getApplicationInfo().processName);
            if(activityProcess && playerActivity==null)
                throw new IllegalStateException("Native TCL browser cannot start without the active Channel+ Activity");
            windowContext=playerActivity!=null ? playerActivity :
                    new ContextThemeWrapper(createDisplayContext(display)
                            .createWindowContext(WindowManager.LayoutParams.TYPE_APPLICATION,null),
                            android.R.style.Theme_Material_NoActionBar);
            Log.i(TAG,"Tbrowser context="+(playerActivity!=null?"Channel+ Activity (1.45-compatible)":"window context"));
            root=new FrameLayout(windowContext); root.setBackgroundColor(Color.TRANSPARENT); root.setAlpha(0f); root.setFocusable(false);
            viewHost=new SurfaceControlViewHost(windowContext,display,data.getBinder(HOST_TOKEN));
            // Public on API 30. Newer LayoutParams overloads cannot be used on TCL Android 11.
            viewHost.setView(root,Math.max(1,data.getInt(WIDTH)),Math.max(1,data.getInt(HEIGHT)));
            SurfaceControlViewHost.SurfacePackage surface=viewHost.getSurfacePackage();
            if(surface==null) throw new IllegalStateException("Browser surface unavailable");
            Bundle result=new Bundle(); result.putParcelable(SURFACE_PACKAGE,surface); reply(SURFACE,result); surface.release();
            Log.d(TAG,"Browser surface attached to Channel+; existing tuner retained channel="+channelId);
            // Registration and Tbrowser may not begin until TDT reports video,
            // so do not arm the watchdog here while the antenna is still tuning.
            if(ready) initialize();
        } catch(Exception | LinkageError error) { fail("Cannot attach embedded browser",error); }
    }
    private void initialize() {
        if(closed || initializing || running) return;
        initializing=true;
        main.removeCallbacks(timeout);
        main.postDelayed(timeout,25000);
        Log.i(TAG,"Autostart: registering the 1.45 native runtime (no colour key)");
        ExperimentalAuthorization.begin(this,authorized->main.post(()->{
            if(closed) return;
            if(!authorized) { fail("Existing 1.45 runtime registration failed",null); return; }
            try {
                VendorBrowserAccess.prepare(windowContext);
                Class.forName("com.tcl.hbbtv.HbbtvServer");
                NativeSection.prepareCertificates(windowContext); NativeUA.prepare(windowContext);
                engine=singleton("com.tcl.hbbtv.HbbtvServer");
                Object initialized=call(engine,"init");
                Log.d(TAG,"HbbtvServer.init="+initialized+"; awaiting browser callback");
                prepareKeys();
                browser=singleton("com.tcl.tbrowser.Tbrowser");
                Class<?> listener=Class.forName("com.tcl.tbrowser.TbrowserInitEventListener");
                initListener=Proxy.newProxyInstance(listener.getClassLoader(),new Class<?>[]{listener},(proxy,method,args)->{
                    if(method.getDeclaringClass()==Object.class) return objectMethod(proxy,method,args);
                    if(method.getName().equals("onSuccess")) {
                        boolean ok=args==null || args.length==0 || !Boolean.FALSE.equals(args[0]);
                        main.post(()->{ if(ok) browserReady(); else fail("Tbrowser onSuccess=false",null); });
                    } else if(method.getName().equals("onFailure") || method.getName().equals("onError")) {
                        main.post(()->fail("Tbrowser reported initialization failure",null));
                    }
                    return defaultValue(method.getReturnType());
                });
                browser.getClass().getMethod("setTbrowserInitEventListener",listener).invoke(browser,initListener);
                browser.getClass().getMethod("initTbrowser",Context.class,ViewGroup.class,boolean.class)
                        .invoke(browser,windowContext,root,false);
            } catch(Exception | LinkageError error) { fail("HbbTV autostart failed",error); }
        }));
    }
    private void browserReady() {
        if(closed || running || engine==null) return;
        browserPrepared=true;
        if(!ready) return;
        try {
            Object result=call(engine,"start");
            if(result instanceof Number && ((Number)result).intValue()<0) throw new IllegalStateException("HbbtvServer.start rejected startup: "+result);
            Log.d(TAG,"HbbtvServer.start="+result+"; no colour key was needed to start engine");
            running=true; initializing=false; main.removeCallbacks(timeout);
            visibility(); reply(STARTED,new Bundle()); inspect.run();
        } catch(Exception | LinkageError error) { fail("HbbtvServer.start failed",error); }
    }
    private void prepareKeys() throws ReflectiveOperationException {
        int[] androidKeys={KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_DPAD_DOWN,KeyEvent.KEYCODE_DPAD_LEFT,KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER,KeyEvent.KEYCODE_BACK,KeyEvent.KEYCODE_PROG_BLUE,
                KeyEvent.KEYCODE_PROG_RED,KeyEvent.KEYCODE_PROG_GREEN,KeyEvent.KEYCODE_PROG_YELLOW};
        String[] names={"UP","DOWN","LEFT","RIGHT","OK","OK","BACK","BLUE","RED","GREEN","YELLOW"};
        Class<?> type=Class.forName("com.tcl.tvmanager.vo.TCLKeyMap$EnTCLKeyMap");
        for(int i=0;i<names.length;i++) {
            try {
                Object value=type.getField("EN_TCL_KEY_"+names[i]).get(null);
                keys.put(androidKeys[i],((Number)type.getMethod("getValue").invoke(value)).intValue());
            } catch(ReflectiveOperationException error) { Log.w(TAG,"Missing TCL key "+names[i],error); }
        }
    }
    private void key(Bundle data) {
        int code=data.getInt(CODE); boolean accepted=false;
        if(running && ready && generation==data.getLong(GENERATION) && channelId==data.getLong(CHANNEL_ID)) {
            Integer vendorCode=keys.get(code);
            if(vendorCode!=null) {
                try {
                    accepted=Boolean.TRUE.equals(engine.getClass().getMethod("handleKey",int.class,int.class).invoke(engine,vendorCode,0));
                    if(accepted && code>=KeyEvent.KEYCODE_PROG_RED && code<=KeyEvent.KEYCODE_PROG_BLUE) { hidden=false; visibility(); }
                    Log.d(TAG,"Runtime key="+code+" TCL="+vendorCode+" handled="+accepted);
                } catch(Exception | LinkageError error) { Log.w(TAG,"Runtime key failed",error); }
            }
        }
        Bundle result=new Bundle(); result.putInt(CODE,code); result.putBoolean(ACCEPTED,accepted);
        result.putLong(KEY_EPOCH,data.getLong(KEY_EPOCH)); result.putLong(GENERATION,data.getLong(GENERATION)); reply(KEY_RESULT,result);
    }
    private void visibility() { if(root!=null) root.setAlpha(running && ready && !hidden ? 1f : 0f); }
    private Object singleton(String name) throws ReflectiveOperationException {
        return Class.forName(name).getMethod("getInstance",Context.class).invoke(null,windowContext);
    }
    private static Object call(Object target,String name) throws ReflectiveOperationException { return target.getClass().getMethod(name).invoke(target); }
    private static Object objectMethod(Object proxy,Method method,Object[] args) {
        switch(method.getName()) {
            case "hashCode": return System.identityHashCode(proxy);
            case "equals": return args!=null && args.length==1 && proxy==args[0];
            case "toString": return "ChannelPlusBrowserListener";
            default: return null;
        }
    }
    private static Object defaultValue(Class<?> type) { if(type==boolean.class) return false; if(type==int.class) return 0; return null; }
    private void reply(int what,Bundle data) {
        if(client==null) return;
        data.putInt(SESSION,session); Message result=Message.obtain(null,what); result.setData(data);
        try { client.send(result); } catch(RemoteException ignored) { cleanup(); }
    }
    private void fail(String reason,Throwable error) {
        if(closed) return;
        Log.e(TAG,reason,error); reply(FAILED,new Bundle()); cleanup();
    }
    private void cleanup() {
        if(closed) return;
        closed=true; main.removeCallbacksAndMessages(null);
        if(root!=null) root.setAlpha(0f);
        if(engine!=null) { try { call(engine,"stopAsync"); } catch(Exception | LinkageError ignored) { } }
        if(browser!=null) { try { call(browser,"destoryPage"); } catch(Exception | LinkageError ignored) { } }
        if(viewHost!=null) { viewHost.release(); viewHost=null; }
        root=null; browser=null; engine=null; client=null; running=false;
    }
    @Override public void onDestroy() {
        cleanup(); super.onDestroy(); liveServices--;
        // Ends only this package's native runtime process, never Channel+'s player or TCL TV's UID.
        // In hbbtv32 the real Channel+ Activity also lives in this process.
        // Killing it on an unbind would black-screen the TV and discard playback.
        if(liveServices==0 && !"com.tcl.tv".equals(getApplicationInfo().processName) &&
                "com.tcl.tv".equals(android.app.Application.getProcessName()) &&
                Process.myUid()==getApplicationInfo().uid)
            Process.killProcess(Process.myPid());
    }
}
