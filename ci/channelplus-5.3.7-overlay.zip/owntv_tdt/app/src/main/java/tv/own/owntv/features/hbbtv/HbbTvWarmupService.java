package tv.own.owntv.features.hbbtv;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/** Warm the isolated class loader without initializing JNI or claiming a tuner. */
public final class HbbTvWarmupService extends Service {
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        for (String name : new String[]{"tv.own.channelplus.lovestvprobe.ProbeActivity",
                "com.tcl.hbbtv.HbbtvServer", "com.tcl.tbrowser.Tbrowser"}) {
            try { Class.forName(name, false, getClassLoader()); }
            catch (ClassNotFoundException | LinkageError unavailable) {
                android.util.Log.d("ChannelplusHbb", "Warmup unavailable: " + name);
            }
        }
        stopSelf(id);
        return START_NOT_STICKY;
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
