package tv.own.owntv.features.more

import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.res.stringResource
import org.koin.androidx.compose.koinViewModel
import tv.own.owntv.R
import tv.own.owntv.features.settings.SettingsViewModel
import tv.own.owntv.ui.stage.StageTab
import tv.own.owntv.ui.theme.mpx

/** Favorites and viewing history share one destination; the former More route stays compatible. */
@Composable
fun FavoritesScreen(
    onPlayChannel: (Long) -> Unit,
    onPlayMovie: (Long, Long) -> Unit,
    onPlayEpisode: (Long, Long, Long) -> Unit,
    onOpenSeries: (Long) -> Unit,
    onChildFocused: () -> Unit,
    onEntryHook: (((() -> Boolean)?) -> Unit)? = null,
    restoreFocus: Boolean = false,
    onRestored: () -> Unit = {},
    modifier: Modifier = Modifier,
    vm: MoreCountsViewModel = koinViewModel(),
    settingsVm: SettingsViewModel = koinViewModel(),
) {
    var history by rememberSaveable { mutableStateOf(false) }
    val tabFocus = remember { FocusRequester() }
    // Focus hooks are callbacks, not UI state: publishing one must not trigger recomposition.
    val pageEntry = remember(history) { arrayOfNulls<() -> Boolean>(1) }
    val enter: () -> Boolean = { pageEntry[0]?.invoke() ?: runCatching { tabFocus.requestFocus() }.getOrDefault(false) }
    DisposableEffect(onEntryHook, history) {
        onEntryHook?.invoke(enter)
        onDispose { onEntryHook?.invoke(null) }
    }
    LaunchedEffect(Unit) { withFrameNanos { }; runCatching { tabFocus.requestFocus() } }
    LaunchedEffect(restoreFocus) {
        if (restoreFocus) { withFrameNanos { }; enter(); onRestored() }
    }
    Column(modifier.fillMaxSize().padding(start = 64.mpx, end = 64.mpx, top = 128.mpx, bottom = 24.mpx)
        .onFocusChanged { if (it.hasFocus) onChildFocused() }) {
        Row(Modifier.fillMaxWidth().padding(bottom = 20.mpx), horizontalArrangement = Arrangement.spacedBy(24.mpx)) {
            StageTab(stringResource(R.string.content_category_favorites), "", !history, { history = false },
                if (!history) Modifier.focusRequester(tabFocus) else Modifier)
            StageTab(stringResource(R.string.content_category_history), "", history, { history = true },
                if (history) Modifier.focusRequester(tabFocus) else Modifier)
        }
        Box(Modifier.weight(1f).fillMaxWidth().focusGroup()) {
            key(history) {
                if (history) HistoryPage(vm, { pageEntry[0] = it },
                    onClearHistory = { settingsVm.clearWatchHistory(it) },
                    onPlayChannel = onPlayChannel, onPlayMovie = onPlayMovie,
                    onPlayEpisode = onPlayEpisode, onOpenSeries = onOpenSeries)
                else FavouritesPage(vm, { pageEntry[0] = it }, onPlayChannel,
                    onPlayMovie = { onPlayMovie(it, 0L) }, onOpenSeries = onOpenSeries)
            }
        }
    }
}
