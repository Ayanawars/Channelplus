package tv.own.owntv.features.epg
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import org.koin.compose.koinInject
import tv.own.owntv.R
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.live.ProviderTags
import tv.own.owntv.core.metadata.*
import tv.own.owntv.core.settings.SettingsRepository
import tv.own.owntv.ui.components.OwnTVIcon
import tv.own.owntv.ui.components.OwnTVPopup
import tv.own.owntv.ui.components.trapAllFocusExit
import tv.own.owntv.ui.metadata.ExternalMetadataBadges
import tv.own.owntv.ui.stage.StageTool
import tv.own.owntv.ui.theme.StageColors
import tv.own.owntv.ui.theme.mpx
import tv.own.owntv.ui.theme.stageText

@Composable
internal fun GuideInformation(channel: ChannelEntity, programme: EpgProgrammeEntity, actions: GuideProgrammeActions,
    loadBroadcasts: suspend () -> List<EpgProgrammeEntity>, onDismiss: () -> Unit) {
    val repository = koinInject<ExternalMetadataRepository>()
    val settings = koinInject<SettingsRepository>()
    val config by repository.store.config.collectAsStateWithLifecycle()
    val profile by settings.activeProfileId.collectAsStateWithLifecycle(initialValue = 0L)
    val language by settings.metadataConfigFlow.collectAsStateWithLifecycle(initialValue = MetadataConfig())
    BackHandler { onDismiss() }
    OwnTVPopup(onDismissRequest = onDismiss, stageLayout = true) {
        key(programme.id, config, profile, language) { InformationBody(channel, programme, actions, repository, loadBroadcasts, onDismiss) }
    }
}
@Composable
private fun InformationBody(channel: ChannelEntity, programme: EpgProgrammeEntity, actions: GuideProgrammeActions,
    repository: ExternalMetadataRepository, loadBroadcasts: suspend () -> List<EpgProgrammeEntity>, onDismiss: () -> Unit) {
    var retry by remember { mutableIntStateOf(0) }
    val information by produceState<ProgrammeInformation?>(null, retry) {
        value = null
        value = try { repository.information(programme.title, programme.details) { value = it } }
            catch (e: CancellationException) { throw e } catch (_: Exception) { ProgrammeInformation(null, incomplete = true) }
    }
    val data = information?.base
    var tab by remember { mutableIntStateOf(0) }
    var season by remember { mutableStateOf<Int?>(null) }
    val episodes by produceState<List<ProgrammeEpisode>?>(null, data?.traktId, season, retry) {
        value = null
        if (data != null && season != null) value = try { repository.informationEpisodes(data, requireNotNull(season)) }
            catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() }
    }
    val broadcasts by produceState<List<EpgProgrammeEntity>?>(null, tab) {
        if (tab == 4) value = try { loadBroadcasts() } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() }
    }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }
    val time = tv.own.owntv.ui.format.rememberSystemTimeFormatter()
    val date = tv.own.owntv.ui.format.rememberBestDateFormatter("yMMMd")
    Box(Modifier.fillMaxSize().background(Color(0xFF07101C))) {
        data?.backdropUrl?.let { AsyncImage(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(650.mpx)) }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF07101C), Color(0xC007101C), Color(0x5007101C)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF07101C)))))
        Column(Modifier.fillMaxSize().padding(64.mpx).verticalScroll(rememberScrollState()).trapAllFocusExit().focusGroup(), verticalArrangement = Arrangement.spacedBy(24.mpx)) {
            Row(horizontalArrangement = Arrangement.spacedBy(28.mpx)) {
                StageTool(stringResource(R.string.programme_back), onDismiss, icon = OwnTVIcon.BACK)
                Text(stringResource(R.string.programme_information), style = stageText(26, 700), color = StageColors.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(40.mpx)) {
                data?.posterUrl?.let { AsyncImage(it, null, contentScale = ContentScale.Fit, modifier = Modifier.width(270.mpx).height(380.mpx)) }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(18.mpx)) {
                    Text(programme.title, style = stageText(54, 800), color = StageColors.Text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    InfoText((listOfNotNull((programme.year ?: data?.year)?.toString(), when(data?.type) {
                        MetadataType.TV -> stringResource(R.string.programme_series); MetadataType.MOVIE -> stringResource(R.string.programme_movie); else -> null }) + data?.genres.orEmpty()).joinToString(stringResource(R.string.programme_separator)))
                    ExternalMetadataBadges(data, details = programme.details)
                    programme.episode?.let { InfoText(it) }
                    InfoText(listOf(ProviderTags.parse(channel.name).name, time(programme.startMs), time(programme.stopMs)).joinToString(stringResource(R.string.programme_separator)))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(12.mpx), verticalArrangement = Arrangement.spacedBy(12.mpx)) {
                        StageTool(stringResource(R.string.content_epg_watch_channel), { onDismiss(); actions.onWatchChannel() }, Modifier.focusRequester(first), icon = OwnTVIcon.PLAY, boxed = true)
                        actions.onReminder?.let { click -> StageTool(stringResource(if(actions.reminderSet) R.string.content_reminder_set else R.string.content_remind_me), click, icon = OwnTVIcon.BELL) }
                        actions.onRecord?.let { click -> StageTool(actions.recordLabel, click, icon = OwnTVIcon.REC) }
                        StageTool(stringResource(if(actions.isFavorite) R.string.content_epg_remove_favourite else R.string.content_epg_add_favourite), actions.onFavorite, icon = OwnTVIcon.FAVORITE)
                    }
                }
            }
            if (information == null || information?.loading == true) InfoText(stringResource(R.string.programme_loading))
            if (information?.incomplete == true) { InfoText(stringResource(R.string.programme_partial)); StageTool(stringResource(R.string.programme_retry), { retry++ }) }
            Row(horizontalArrangement = Arrangement.spacedBy(18.mpx)) {
                listOf(0 to R.string.programme_synopsis, 1 to R.string.programme_cast, 2 to R.string.programme_seasons, 3 to R.string.programme_technical, 4 to R.string.programme_broadcasts).forEach { (i,label) ->
                    if (i != 2 || data?.type == MetadataType.TV) StageTool(stringResource(label), { tab = i }, boxed = tab == i)
                }
            }
            key(tab) {
                Column(verticalArrangement = Arrangement.spacedBy(18.mpx)) {
                    when(tab) {
                        0 -> { InfoText(data?.overview ?: data?.tvdbOverview ?: programme.description ?: stringResource(R.string.programme_unavailable), true); InformationCast(information?.cast.orEmpty().take(4)) }
                        1 -> { if (information?.cast.isNullOrEmpty()) InfoText(stringResource(R.string.programme_unavailable)); InformationCast(information?.cast.orEmpty()) }
                        2 -> {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.mpx)) {
                                information?.seasons.orEmpty().forEach { item -> StageTool(stringResource(R.string.programme_season_number,item.number), { season = item.number }, boxed = season == item.number) }
                            }
                            if (information?.seasons.isNullOrEmpty()) InfoText(stringResource(R.string.programme_unavailable))
                            if (season != null && episodes == null) InfoText(stringResource(R.string.programme_loading))
                            if (season != null && episodes?.isEmpty() == true) { InfoText(stringResource(R.string.programme_unavailable)); StageTool(stringResource(R.string.programme_retry), { retry++ }) }
                            episodes.orEmpty().forEach { ep -> InfoText(listOfNotNull(stringResource(R.string.programme_episode_number,ep.number), ep.title, ep.firstAired, ep.runtime?.let { stringResource(R.string.programme_minutes,it) }).joinToString(stringResource(R.string.programme_separator)), true); ep.overview?.let { InfoText(it, true) } }
                        }
                        3 -> {
                            InfoField(R.string.programme_original, information?.originalTitle)
                            InfoField(R.string.programme_runtime, (information?.runtime ?: programme.lengthMin)?.let { stringResource(R.string.programme_minutes,it) })
                            InfoField(R.string.programme_country, information?.country?.let { java.util.Locale("",it).displayCountry })
                            InfoField(R.string.programme_original_language, information?.language?.let { java.util.Locale.forLanguageTag(it).displayLanguage })
                            InfoField(R.string.programme_status, information?.status)
                            InfoField(R.string.programme_network, information?.network)
                            InfoField(R.string.programme_premiere, information?.firstAired)
                            InfoField(R.string.programme_directors, information?.directors?.takeIf { it.isNotEmpty() }?.joinToString(stringResource(R.string.programme_separator)))
                            InfoField(R.string.programme_writers, information?.writers?.takeIf { it.isNotEmpty() }?.joinToString(stringResource(R.string.programme_separator)))
                            if (data == null) InfoText(stringResource(R.string.programme_unavailable))
                        }
                        4 -> {
                            InfoText(stringResource(R.string.programme_broadcast_scope))
                            if (broadcasts == null) InfoText(stringResource(R.string.programme_loading))
                            if (broadcasts?.isEmpty() == true) InfoText(stringResource(R.string.programme_unavailable))
                            broadcasts.orEmpty().forEach { p -> InfoText(listOf(date(p.startMs),time(p.startMs),time(p.stopMs),p.title).joinToString(stringResource(R.string.programme_separator)), true) }
                        }
                    }
                }
            }
            InfoText(stringResource(R.string.programme_sources))
        }
    }
}
@Composable
private fun InformationCast(cast: List<ProgrammePerson>) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(28.mpx), verticalArrangement = Arrangement.spacedBy(24.mpx)) {
        cast.forEach { person ->
            Column(Modifier.width(180.mpx).focusable(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(130.mpx).clip(CircleShape).background(StageColors.ControlFill), contentAlignment = Alignment.Center) {
                    Text(person.name.split(' ').mapNotNull { it.firstOrNull() }.take(2).joinToString(""), style = stageText(26,700), color = StageColors.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    person.photoUrl?.let { AsyncImage(it, person.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
                }
                Text(person.name, style = stageText(20,600), color = StageColors.Text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                person.role?.let { Text(it, style = stageText(17,400), color = StageColors.Muted, maxLines = 2, overflow = TextOverflow.Ellipsis) }
            }
        }
    }
}
@Composable
private fun InfoText(text: String, focusable: Boolean = false) {
    var focused by remember { mutableStateOf(false) }
    if (text.isNotBlank()) Text(text, style = stageText(23,400), color = StageColors.Body, overflow = TextOverflow.Ellipsis,
        modifier = if(focusable) Modifier.fillMaxWidth().background(if(focused) Color(0x33249CFF) else Color.Transparent).padding(8.mpx).onFocusChanged { focused = it.isFocused }.focusable() else Modifier)
}
@Composable
private fun InfoField(label: Int, value: String?) { if(!value.isNullOrBlank()) InfoText(stringResource(label)+stringResource(R.string.programme_separator)+value,true) }
