package tv.own.owntv.features.hbbtv;

import android.app.Activity;
import android.app.AlertDialog;
import tv.own.owntv.R;

/** Native escape and diagnostics remain available even when the provider page is unresponsive. */
public final class HbbTvMenu {
    public static void show(Activity activity) {
        new AlertDialog.Builder(activity)
            .setTitle(R.string.hbbtv_menu)
            .setItems(new CharSequence[]{activity.getText(R.string.hbbtv_continue),
                activity.getText(R.string.hbbtv_exit), activity.getText(R.string.hbbtv_report)}, (dialog, item) -> {
                if (item == 1) activity.finish();
                if (item == 2) {
                    try {
                        Class<?> type = Class.forName("tv.own.channelplus.lovestvprobe.ReportExport");
                        java.lang.reflect.Method method = type.getDeclaredMethod("start", Activity.class);
                        method.setAccessible(true); method.invoke(null, activity);
                    } catch (Exception failure) { android.util.Log.w("ChannelplusHbb", "Report export unavailable", failure); }
                }
            }).show();
    }
}
