package tv.own.owntv.features.epg
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.tv.material3.Text
import coil3.compose.AsyncImage
import tv.own.owntv.R
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.live.ProviderTags
import tv.own.owntv.core.metadata.MetadataType
import tv.own.owntv.core.metadata.SpanishProgrammeBadges
import tv.own.owntv.player.LivePreviewEngine
import tv.own.owntv.ui.metadata.ExternalMetadataBadges
import tv.own.owntv.ui.metadata.rememberExternalMetadata
import tv.own.owntv.ui.theme.StageColors
import tv.own.owntv.ui.theme.mpx
import tv.own.owntv.ui.theme.stageText
@Composable
internal fun GuideHero(channel: ChannelEntity?, programme: EpgProgrammeEntity?, now: Long, engine: LivePreviewEngine,
    videoChannel: ChannelEntity?, liveTitle: String?, showVideo: Boolean, modifier: Modifier = Modifier) {
    val external = rememberExternalMetadata(programme?.title, programme?.details)
    val name = channel?.let { ProviderTags.parse(it.name).name }.orEmpty()
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(28.mpx)) {
        (external?.posterUrl ?: external?.tvdbArtwork)?.let { AsyncImage(it,null,contentScale=ContentScale.Fit, modifier=Modifier.width(182.mpx).fillMaxHeight()) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.mpx)) {
            Text(programme?.title ?: name,style=stageText(43,800),color=StageColors.Text,maxLines=1,overflow=TextOverflow.Ellipsis)
            if(programme != null) {
                Text(programmeEyebrow(programme,name,now),style=stageText(17,600),color=StageColors.Muted,maxLines=1,overflow=TextOverflow.Ellipsis)
                val progress=((now-programme.startMs).toFloat()/(programme.stopMs-programme.startMs).coerceAtLeast(1L)).coerceIn(0f,1f)
                Box(Modifier.fillMaxWidth().height(5.mpx).background(Color(0xFF26364D))) { Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Color(0xFF249CFF))) }
                Text(programme.description ?: external?.overview ?: external?.tvdbOverview.orEmpty(),style=stageText(18,400),color=StageColors.Body,maxLines=2,overflow=TextOverflow.Ellipsis)
                ExternalMetadataBadges(external,details=programme.details,compact=true)
                val type=when(external?.type) { MetadataType.TV -> stringResource(R.string.programme_series); MetadataType.MOVIE -> stringResource(R.string.programme_movie); else -> null }
                val genres=programme.details.categoryList.filter { SpanishProgrammeBadges.descriptors(listOf(it)).isEmpty() }.ifEmpty { external?.genres.orEmpty() }
                Text((listOfNotNull((programme.year ?: external?.year)?.toString(),type,programme.episode)+genres.take(3)).distinct().joinToString(stringResource(R.string.programme_separator)),style=stageText(17,500),color=StageColors.Muted,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
        }
        GuideVideo(videoChannel,videoChannel?.let { ProviderTags.parse(it.name).name },liveTitle,engine,showVideo,Modifier.width(520.mpx))
    }
}
