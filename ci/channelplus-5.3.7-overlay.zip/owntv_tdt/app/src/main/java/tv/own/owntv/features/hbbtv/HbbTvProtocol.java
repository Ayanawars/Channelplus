package tv.own.owntv.features.hbbtv;

/** Private, same-UID Messenger protocol between the player and its browser process. */
public final class HbbTvProtocol {
    private HbbTvProtocol() {}
    public static final int ATTACH=1, CHANNEL=2, KEY=3, RESIZE=4, HIDE=5;
    public static final int SURFACE=10, STARTED=11, KEY_RESULT=12, FAILED=13;
    public static final String SESSION="session", HOST_TOKEN="host_token", DISPLAY="display",
            WIDTH="width", HEIGHT="height", SURFACE_PACKAGE="surface_package", CHANNEL_ID="channel_id",
            INPUT_ID="input_id", VIDEO_READY="video_ready", CODE="code", GENERATION="generation",
            ACCEPTED="accepted", KEY_EPOCH="key_epoch";
}
