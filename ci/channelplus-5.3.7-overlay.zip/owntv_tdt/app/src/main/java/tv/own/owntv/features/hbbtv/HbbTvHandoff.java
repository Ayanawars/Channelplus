package tv.own.owntv.features.hbbtv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.io.File;
import java.io.FileOutputStream;
import java.util.UUID;
import java.util.WeakHashMap;

/** Private, temporary frame spanning the transfer between the two tuner sessions. */
public final class HbbTvHandoff {
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static final WeakHashMap<Activity, Object> pending = new WeakHashMap<>();
    private static boolean released = true;
    private HbbTvHandoff() {}
    public static void cancel(Activity activity) { pending.remove(activity); }
    public static boolean pending(Activity activity) { return pending.containsKey(activity); }
    public static void playerReleased() { released = true; }
    static boolean isPlayerReleased() { return released; }

    public static void launch(Activity activity, Intent intent) {
        if (pending.containsKey(activity)) return;
        Object request = new Object();
        pending.put(activity, request);
        String token = UUID.randomUUID().toString();
        File target = frameFile(activity, token);
        Runnable open = () -> {
            if (pending.get(activity) != request) { target.delete(); return; }
            pending.remove(activity);
            if (activity.isFinishing() || activity.isDestroyed() || !activity.hasWindowFocus()) {
                target.delete(); return;
            }
            released = false;
            if (target.isFile()) intent.putExtra("handoff_frame", token);
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            try { activity.startActivity(intent); activity.overridePendingTransition(0, 0); }
            catch (RuntimeException failure) {
                released = true; target.delete();
                android.util.Log.e("ChannelplusHbb", "Cannot open HbbTV", failure);
            }
        };
        main.postDelayed(open, 700);
        SurfaceView surface = videoSurface(activity.getWindow().getDecorView(), null);
        if (surface == null) { main.removeCallbacks(open); open.run(); return; }
        float ratio = Math.min(1f, 1280f / surface.getWidth());
        Bitmap bitmap = Bitmap.createBitmap(Math.max(1, Math.round(surface.getWidth() * ratio)),
                Math.max(1, Math.round(surface.getHeight() * ratio)), Bitmap.Config.ARGB_8888);
        try {
            PixelCopy.request(surface, bitmap, result -> {
                if (result != PixelCopy.SUCCESS || pending.get(activity) != request) {
                    bitmap.recycle(); main.removeCallbacks(open); open.run(); return;
                }
                new Thread(() -> {
                    try (FileOutputStream output = new FileOutputStream(target)) {
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 88, output);
                    } catch (Exception failure) { target.delete(); }
                    finally { bitmap.recycle(); }
                    main.post(() -> { main.removeCallbacks(open); open.run(); });
                }, "hbbtv-frame").start();
            }, main);
        } catch (RuntimeException failure) {
            bitmap.recycle(); main.removeCallbacks(open); open.run();
        }
    }
    private static SurfaceView videoSurface(View view, SurfaceView best) {
        if (!view.isShown()) return best;
        if (view instanceof SurfaceView && view.getWidth() > 0 && view.getHeight() > 0 &&
                ((SurfaceView) view).getHolder().getSurface().isValid() &&
                (best == null || (long) view.getWidth() * view.getHeight() > (long) best.getWidth() * best.getHeight()))
            best = (SurfaceView) view;
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) best = videoSurface(group.getChildAt(i), best);
        }
        return best;
    }
    private static File frameFile(Activity activity, String token) {
        return new File(activity.getCacheDir(), "hbbtv-frame-" + token + ".jpg");
    }
    private static String token(Activity activity) {
        String value = activity.getIntent().getStringExtra("handoff_frame");
        return value != null && value.matches("[a-f0-9-]{36}") ? value : null;
    }
    /** Called reflectively in the isolated runtime. */
    public static View showFrame(Activity activity, ViewGroup parent) {
        String token = token(activity);
        if (token == null) return null;
        Bitmap bitmap = BitmapFactory.decodeFile(frameFile(activity, token).getAbsolutePath());
        if (bitmap == null) return null;
        ImageView image = new ImageView(activity);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackgroundColor(0xff000000);
        image.setImageBitmap(bitmap);
        image.setFocusable(false);
        parent.addView(image, new ViewGroup.LayoutParams(-1, -1));
        return image;
    }
    public static void clearFrame(Activity activity) {
        String token = token(activity);
        if (token != null) frameFile(activity, token).delete();
    }
}
