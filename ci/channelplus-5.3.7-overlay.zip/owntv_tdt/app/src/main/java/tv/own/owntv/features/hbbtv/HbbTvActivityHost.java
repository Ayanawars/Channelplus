package tv.own.owntv.features.hbbtv;

import android.app.Activity;
import java.lang.ref.WeakReference;

/**
 * Exposes the currently visible player Activity to the native TCL browser when
 * the dedicated hbbtv32 flavor places Channel+ and its HbbTV service in the
 * same 32-bit process. This is NOT an IPC channel or a second player.
 */
public final class HbbTvActivityHost {
    private static WeakReference<Activity> active=new WeakReference<>(null);
    private HbbTvActivityHost() { }

    public static synchronized void attach(Activity activity) {
        if(activity!=null) active=new WeakReference<>(activity);
    }
    public static synchronized Activity current() {
        Activity activity=active.get();
        return activity!=null && !activity.isFinishing() && !activity.isDestroyed() ? activity : null;
    }
    public static synchronized void detach(Activity activity) {
        if(active.get()==activity) active.clear();
    }
}
