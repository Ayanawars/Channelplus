package tv.own.owntv.features.hbbtv;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.widget.FrameLayout;

/** Holds the main player stopped across all vendor channel switches, until the child exits. */
public final class HbbTvEntryActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean launched;
    private boolean covered;
    private long returnStarted;
    private long handoffStarted;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FrameLayout frame = new FrameLayout(this);
        setContentView(frame);
        HbbTvHandoff.showFrame(this, frame);
        handoffStarted = SystemClock.elapsedRealtime();
        launched = state != null && state.getBoolean("launched");
        if (!launched) handler.post(this::awaitPlayerRelease);
    }

    private void awaitPlayerRelease() {
        if (isFinishing() || isDestroyed()) return;
        if (!HbbTvHandoff.isPlayerReleased()) {
            if (SystemClock.elapsedRealtime() - handoffStarted > 1500) { finish(); return; }
            handler.postDelayed(this::awaitPlayerRelease, 16);
            return;
        }
        open();
    }

    private void open() {
        if (isFinishing() || isDestroyed()) return;
        String input = getIntent().getStringExtra("input");
        long id = getIntent().getLongExtra("id", -1);
        if (!HbbTvLauncher.supported(input, id, Process.is64Bit(),
                new java.io.File("/product/framework/com.tcl.hbbtv.jar").isFile())) { finish(); return; }
        Intent intent = new Intent();
        intent.setClassName(getPackageName(), "tv.own.channelplus.lovestvprobe.ProbeActivity");
        intent.putExtras(getIntent());
        intent.putExtra("integrated", true);
        intent.putExtra("group_auto", getIntent().getIntExtra("initial_key", 186) == 186);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        launched = true;
        try { startActivity(intent); overridePendingTransition(0, 0); }
        catch (RuntimeException failure) { android.util.Log.e("ChannelplusHbb", "Cannot start HbbTV", failure); finish(); }
    }

    @Override protected void onPause() { super.onPause(); if (launched) covered = true; }
    @Override protected void onStop() {
        super.onStop();
        if (!launched) { handler.removeCallbacksAndMessages(null); finish(); }
    }
    @Override protected void onResume() {
        super.onResume();
        if (launched && (covered || !hasWindowFocus())) {
            returnStarted = SystemClock.elapsedRealtime();
            handler.postDelayed(this::awaitRelease, 250);
        }
    }
    private void awaitRelease() {
        if (isFinishing() || isDestroyed()) return;
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int runtimePid = -1;
        if (manager != null && manager.getRunningAppProcesses() != null) {
            for (ActivityManager.RunningAppProcessInfo process : manager.getRunningAppProcesses()) {
                if (process.uid == Process.myUid() && process.pid != Process.myPid() &&
                        "com.tcl.tv".equals(process.processName)) runtimePid = process.pid;
            }
        }
        if (runtimePid < 0) { finish(); return; }
        if (SystemClock.elapsedRealtime() - returnStarted < 4000) { handler.postDelayed(this::awaitRelease, 100); return; }
        // Only our own child, after its screen has closed. Never the stock TCL application's UID.
        Process.killProcess(runtimePid);
        handler.postDelayed(this::finish, 200);
    }
    @Override protected void onSaveInstanceState(Bundle state) { state.putBoolean("launched", launched); super.onSaveInstanceState(state); }
    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (isFinishing()) HbbTvHandoff.clearFrame(this);
        super.onDestroy();
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        // No residual OK/color press can start a second session during the handoff.
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_UP) finish();
            return true;
        }
        return true;
    }
}
