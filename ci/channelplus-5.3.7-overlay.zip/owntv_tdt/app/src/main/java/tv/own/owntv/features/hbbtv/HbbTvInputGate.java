package tv.own.owntv.features.hbbtv;

/** Rejects late IPC replies after Back, a newer request, or a channel change. */
final class HbbTvInputGate {
    private long generation, epoch;
    private boolean interactive;
    void channel(long value, boolean videoReady) {
        if (generation != value || !videoReady) leave();
        generation = value;
    }
    long beginColour() { interactive=false; return ++epoch; }
    long epoch() { return epoch; }
    boolean interactive() { return interactive; }
    void accepted(long forGeneration, long forEpoch, boolean accepted) {
        if (generation == forGeneration && epoch == forEpoch) interactive=accepted;
    }
    void leave() { epoch++; interactive=false; }
}
