package tv.own.owntv.features.hbbtv;

import android.app.Activity;
import android.content.*;
import android.graphics.PixelFormat;
import android.media.tv.TvView;
import android.os.*;
import android.os.Process;
import android.util.Log;
import android.view.*;
import android.widget.FrameLayout;
import java.io.File;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import static tv.own.owntv.features.hbbtv.HbbTvProtocol.*;

/** One existing tuner, with a remote transparent HbbTV browser above its video. */
public final class HbbTvPlayerView extends FrameLayout {
    private static final String TAG="ChannelplusHbb";
    private static final AtomicInteger serial=new AtomicInteger();
    private static final WeakHashMap<Activity,HbbTvPlayerView> owners=new WeakHashMap<>();
    private final TvView tvView;
    private final Activity activity;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Set<Integer> consumed=new HashSet<>();
    private final HbbTvInputGate gate=new HbbTvInputGate();
    private final Messenger reply=new Messenger(new Handler(Looper.getMainLooper(),this::receive));
    private SurfaceView overlay;
    private ServiceConnection connection;
    private Messenger remote;
    private boolean enabled,ready,surfaceReady,attached,started,failed,released;
    private String input;
    private long channelId=-1,generation;
    private int session;
    private final Runnable timeout=()->{ if(!started && connection!=null) fail("Runtime startup timed out",null); };

    public HbbTvPlayerView(Context context) {
        super(context);
        activity=activityOf(context);
        // In hbbtv32 the native TCL service is in this same process. It can
        // pass this real Activity to Tbrowser (as the working 1.45 probe did).
        HbbTvActivityHost.attach(activity);
        tvView=new TvView(context);
        tvView.setFocusable(false);
        addView(tvView,new LayoutParams(-1,-1));
        if(Build.VERSION.SDK_INT>=30 && !Process.is64Bit() && new File("/product/framework/com.tcl.hbbtv.jar").isFile()) {
            overlay=new SurfaceView(context);
            overlay.setZOrderMediaOverlay(true);
            overlay.getHolder().setFormat(PixelFormat.TRANSLUCENT);
            overlay.setFocusable(false); overlay.setClickable(false);
            addView(overlay,new LayoutParams(-1,-1));
            overlay.getHolder().addCallback(new SurfaceHolder.Callback() {
                @Override public void surfaceCreated(SurfaceHolder holder) { surfaceReady=true; connect(); }
                @Override public void surfaceChanged(SurfaceHolder holder,int format,int width,int height) {
                    connect(); if(attached) send(RESIZE,dimensions());
                }
                @Override public void surfaceDestroyed(SurfaceHolder holder) { surfaceReady=false; disconnect(); }
            });
        }
    }
    public TvView getTvView() { return tvView; }
    public void updateHbbTv(String inputId,long id,boolean videoReady,long tuneGeneration,boolean activePlayer) {
        if(released) return;
        // A failed vendor runtime must never poison a later channel or retune.
        // Retry only on a genuine tune change, not on each recomposition/frame.
        if(id!=channelId || !java.util.Objects.equals(input,inputId) || generation!=tuneGeneration) {
            gate.leave();
            if(failed) { failed=false; Log.i(TAG,"Retry HbbTV on new tuner generation="+tuneGeneration); }
        }
        input=inputId; channelId=id; generation=tuneGeneration; ready=videoReady;
        gate.channel(generation,ready);
        enabled=activePlayer && input!=null && input.startsWith("com.tcl.tvinput/.TDTVInputService/") && id>=0;
        if(!enabled) { disconnect(); return; }
        if(overlay!=null && !failed) overlay.setVisibility(View.VISIBLE);
        if(activity!=null) owners.put(activity,this);
        if(remote!=null && attached) send(CHANNEL,channel());
        // Connect and create the embedded surface as soon as the TCL TIF channel
        // is known. The runtime itself waits for video before HbbtvServer.init.
        connect();
        armTimeoutIfVideoReady();
    }
    private void connect() {
        if(released || failed || !enabled || !surfaceReady || overlay==null || getWidth()==0 || getHeight()==0) return;
        if(remote!=null) { attachRemote(); return; }
        if(connection!=null) return;
        session=serial.incrementAndGet();
        ServiceConnection candidate=new ServiceConnection() {
            @Override public void onServiceConnected(ComponentName name,IBinder binder) {
                if(connection!=this || released) return;
                remote=new Messenger(binder); attachRemote();
            }
            @Override public void onServiceDisconnected(ComponentName name) {
                if(connection==this) fail("Runtime disconnected; TDT remains active",null);
            }
            @Override public void onBindingDied(ComponentName name) { if(connection==this) fail("Runtime binding died",null); }
            @Override public void onNullBinding(ComponentName name) { if(connection==this) fail("Runtime refused binding",null); }
        };
        connection=candidate;
        try {
            Intent intent=new Intent().setClassName(getContext(),"tv.own.channelplus.lovestvprobe.HbbTvRuntimeService");
            if(!getContext().bindService(intent,candidate,Context.BIND_AUTO_CREATE)) {
                connection=null; fail("Runtime service unavailable",null); return;
            }
            Log.d(TAG,"Autostart bound on TCL TDT channel="+channelId+" videoReady="+ready);
            armTimeoutIfVideoReady();
        } catch(RuntimeException error) { fail("Cannot bind runtime",error); }
    }
    @android.annotation.TargetApi(30)
    private void attachRemote() {
        if(attached || !surfaceReady || !enabled || remote==null || overlay.getDisplay()==null) return;
        Bundle data=dimensions(); data.putAll(channel());
        data.putBinder(HOST_TOKEN,overlay.getHostToken()); data.putInt(DISPLAY,overlay.getDisplay().getDisplayId());
        attached=true; send(ATTACH,data);
        armTimeoutIfVideoReady();
    }
    private void armTimeoutIfVideoReady() {
        main.removeCallbacks(timeout);
        // Never time out an engine that has not been asked to initialize: a
        // slow/weak TDT signal can take longer than the runtime watchdog.
        if(connection!=null && attached && ready && !started) main.postDelayed(timeout,30000);
    }
    private Bundle dimensions() {
        Bundle data=new Bundle(); data.putInt(WIDTH,Math.max(1,getWidth())); data.putInt(HEIGHT,Math.max(1,getHeight())); return data;
    }
    private Bundle channel() {
        Bundle data=new Bundle(); data.putString(INPUT_ID,input); data.putLong(CHANNEL_ID,channelId);
        data.putLong(GENERATION,generation); data.putBoolean(VIDEO_READY,ready); return data;
    }
    private void send(int what,Bundle data) {
        if(remote==null) return;
        data.putInt(SESSION,session);
        Message message=Message.obtain(null,what); message.setData(data); message.replyTo=reply;
        try { remote.send(message); } catch(RemoteException error) { fail("Runtime message failed",error); }
    }
    @android.annotation.TargetApi(30)
    private boolean receive(Message message) {
        Bundle data=message.getData(); data.setClassLoader(SurfaceControlViewHost.SurfacePackage.class.getClassLoader());
        SurfaceControlViewHost.SurfacePackage surface=data.getParcelable(SURFACE_PACKAGE);
        if(released || connection==null || data.getInt(SESSION)!=session) {
            if(surface!=null) surface.release(); return true;
        }
        switch(message.what) {
            case SURFACE:
                if(surface!=null) {
                    if(surfaceReady) {
                        try { overlay.setChildSurfacePackage(surface); }
                        catch(RuntimeException error) { surface.release(); fail("Cannot display runtime surface",error); }
                    } else surface.release();
                }
                break;
            case STARTED:
                started=true; failed=false; main.removeCallbacks(timeout);
                Log.d(TAG,"HbbTV engine started before key; broadcaster rendering still requires device confirmation"); break;
            case KEY_RESULT:
                if(ready && colour(data.getInt(CODE))) {
                    gate.accepted(data.getLong(GENERATION),data.getLong(KEY_EPOCH),data.getBoolean(ACCEPTED));
                } else if(ready && data.getInt(CODE)==KeyEvent.KEYCODE_BACK &&
                        data.getLong(GENERATION)==generation && data.getLong(KEY_EPOCH)==gate.epoch() &&
                        !data.getBoolean(ACCEPTED)) {
                    // The actual 1.45 integration returns to live TV only when
                    // the native engine declines Back; do not hide LOVEStv while
                    // the broadcaster uses Back to navigate its own pages.
                    gate.leave(); send(HIDE,channel());
                    Log.d(TAG,"LOVEStv finished; Channel+ remote navigation restored");
                }
                break;
            case FAILED: fail("Runtime initialization failed; see preceding ChannelplusHbb log",null); break;
            default: break;
        }
        return true;
    }
    public static boolean dispatch(Activity owner,KeyEvent event) {
        HbbTvPlayerView host=owners.get(owner); return host!=null && host.key(event);
    }
    private static boolean colour(int code) { return code>=KeyEvent.KEYCODE_PROG_RED && code<=KeyEvent.KEYCODE_PROG_BLUE; }
    private boolean key(KeyEvent event) {
        int code=event.getKeyCode();
        if(event.getAction()==KeyEvent.ACTION_UP) return consumed.remove(code);
        if(event.getAction()!=KeyEvent.ACTION_DOWN) return false;
        if(code==KeyEvent.KEYCODE_CHANNEL_UP || code==KeyEvent.KEYCODE_CHANNEL_DOWN) {
            gate.leave(); send(HIDE,channel()); return false;
        }
        if(!enabled || !ready || !started || remote==null) {
            if(colour(code)) Log.d(TAG,"Colour key before runtime readiness code="+code);
            return false;
        }
        boolean colour=colour(code);
        boolean navigation=code==KeyEvent.KEYCODE_DPAD_UP || code==KeyEvent.KEYCODE_DPAD_DOWN || code==KeyEvent.KEYCODE_DPAD_LEFT ||
                code==KeyEvent.KEYCODE_DPAD_RIGHT || code==KeyEvent.KEYCODE_DPAD_CENTER || code==KeyEvent.KEYCODE_ENTER || code==KeyEvent.KEYCODE_BACK;
        if(!colour && !(gate.interactive() && navigation)) return false;
        if(colour && event.getRepeatCount()>0) return consumed.contains(code);
        consumed.add(code); if(colour) gate.beginColour();
        Bundle data=channel(); data.putInt(CODE,code); data.putLong(KEY_EPOCH,gate.epoch()); send(KEY,data);
        // Keep the broadcaster visible while it handles Back. A rejected Back
        // acknowledgment releases capture in KEY_RESULT above.
        return true;
    }
    private void fail(String reason,Throwable error) { Log.w(TAG,reason,error); failed=true; disconnect(); }
    private void disconnect() {
        main.removeCallbacks(timeout);
        if(activity!=null && owners.get(activity)==this) owners.remove(activity);
        ServiceConnection old=connection; connection=null; remote=null; attached=false; started=false; gate.leave();
        if(overlay!=null) overlay.setVisibility(View.INVISIBLE);
        if(old!=null) { try { getContext().unbindService(old); } catch(IllegalArgumentException ignored) { } }
    }
    public void release() {
        released=true; disconnect(); consumed.clear();
        HbbTvActivityHost.detach(activity);
    }
    private static Activity activityOf(Context context) {
        while(context instanceof ContextWrapper) {
            if(context instanceof Activity) return (Activity)context;
            Context next=((ContextWrapper)context).getBaseContext(); if(next==context) break; context=next;
        }
        return null;
    }
}
