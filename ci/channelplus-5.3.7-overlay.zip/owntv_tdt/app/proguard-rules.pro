# OwnTV release keep rules (R8). Each rule guards a runtime lookup that R8 can't see
# statically — trim only with a full on-device regression (sync, both engines, backup).

# --- Crash reports: keep readable stack traces (mapping.txt still needed for names) ---
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# --- libmpv JNI: native code resolves MPVLib and its event callbacks by name ---
-keep class dev.jdtech.mpv.** { *; }

# --- WorkManager: workers are re-instantiated by FQCN string (KoinWorkerFactory matches
#     workerClassName against ::class.java.name, and WorkManager persists the name in its DB
#     across app updates) ---
-keep class * extends androidx.work.ListenableWorker

# --- Room: Room.getGeneratedImplementation() derives this exact class name and loads it
#     reflectively. Keep the generated database entry point in optimized release builds. ---
-keep class tv.own.owntv.core.database.OwnTVDatabase_Impl { *; }

# --- Persisted enum names: DataStore prefs, backup JSON ("t" = MediaType.name), and
#     per-setting modes (ZoomMode, ThemeMode, StartupMode, AnimationLevel, ResumeMode,
#     EpgAutoRefresh, PlaylistAutoRefresh, ...) round-trip through Enum.name/valueOf.
#     Renaming a constant would silently reset settings and break old backups. ---
-keep enum tv.own.owntv.** { *; }

# Vendor JNI/reflection contracts from the tested standalone HbbTV runtime.
-keep class tv.own.channelplus.lovestvprobe.** { *; }
-keep class org.lsposed.hiddenapibypass.** { *; }
# Android ART provides this internal type; it is intentionally absent from the public SDK stubs.
# The retained bypass runtime uses it on the already-tested G07/Android 11 path only.
-dontwarn sun.misc.Unsafe
-dontwarn dalvik.system.VMRuntime

-keep class tv.own.owntv.features.hbbtv.HbbTvMenu { public static void show(android.app.Activity); }

-keep class tv.own.owntv.features.hbbtv.HbbTvHandoff { public static android.view.View showFrame(android.app.Activity, android.view.ViewGroup); }
